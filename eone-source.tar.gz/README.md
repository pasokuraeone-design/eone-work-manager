# イーワンスクエア 仕事管理

山手新棟オープンプロジェクトの管理Webアプリです。

- GitHub Pagesで公開
- Googleログインでアクセス制限
- Firebase Firestoreで複数端末同期
- 旧ChatGPT Sites版は移行確認が終わるまで保持

## 開発

```bash
npm install
npm run dev
```

## ビルド

```bash
npm run build
```

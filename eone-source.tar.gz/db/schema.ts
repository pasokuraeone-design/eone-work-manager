import {
  index,
  integer,
  real,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

export const projectUpdateLog = sqliteTable("project_update_log", {
  key: text("key").primaryKey(),
});

export const tasks = sqliteTable(
  "tasks",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    name: text("name").notNull(),
    category: text("category").notNull(),
    scope: text("scope").notNull().default("新棟オープン"),
    dueDate: text("due_date").notNull(),
    assignee: text("assignee").notNull().default("藤田"),
    priority: text("priority").notNull().default("中"),
    status: text("status").notNull().default("未着手"),
    memo: text("memo").notNull().default(""),
    nextAction: text("next_action").notNull().default(""),
    contact: text("contact").notNull().default(""),
    resourceUrl: text("resource_url").notNull().default(""),
    startMonth: text("start_month").notNull().default("2026-09"),
    endMonth: text("end_month").notNull().default("2026-09"),
  },
  (t) => [
    uniqueIndex("idx_tasks_name_unique").on(t.name),
    index("idx_tasks_due_status").on(t.dueDate, t.status),
    index("idx_tasks_category").on(t.category),
    index("idx_tasks_scope_due").on(t.scope, t.dueDate),
  ],
);
export const candidates = sqliteTable(
  "candidates",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    alias: text("alias").notNull(),
    supportLevel: text("support_level").notNull().default("未確認"),
    daytimePlace: text("daytime_place").notNull().default(""),
    supportOffice: text("support_office").notNull().default(""),
    consultant: text("consultant").notNull().default(""),
    interest: text("interest").notNull().default("情報提供のみ"),
    familyIntent: text("family_intent").notNull().default("未確認"),
    tourStatus: text("tour_status").notNull().default("未実施"),
    trialStatus: text("trial_status").notNull().default("未実施"),
    expectedMoveIn: text("expected_move_in").notNull().default("2027-08"),
    nextContactDate: text("next_contact_date").notNull().default(""),
    memo: text("memo").notNull().default(""),
  },
  (t) => [index("idx_candidates_interest").on(t.interest)],
);
export const funds = sqliteTable(
  "funds",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    item: text("item").notNull(),
    estimated: integer("estimated").notNull().default(0),
    confirmed: integer("confirmed").notNull().default(0),
    paid: integer("paid").notNull().default(0),
    memo: text("memo").notNull().default(""),
  },
  (t) => [uniqueIndex("idx_funds_item_unique").on(t.item)],
);
export const loans = sqliteTable("loans", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  lender: text("lender").notNull(),
  requested: integer("requested").notNull().default(0),
  consultationDate: text("consultation_date").notNull().default(""),
  response: text("response").notNull().default("未相談"),
  memo: text("memo").notNull().default(""),
});

export const projectDocuments = sqliteTable(
  "project_documents",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    title: text("title").notNull(),
    category: text("category").notNull(),
    summary: text("summary").notNull().default(""),
    keyNumbers: text("key_numbers").notNull().default(""),
    updatedDate: text("updated_date").notNull().default(""),
    driveUrl: text("drive_url").notNull(),
    relatedTaskIds: text("related_task_ids").notNull().default(""),
  },
  (t) => [
    index("idx_project_documents_category").on(t.category),
    index("idx_project_documents_updated_date").on(t.updatedDate),
  ],
);

export const borrowings = sqliteTable(
  "borrowings",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    lender: text("lender").notNull(),
    originalAmount: integer("original_amount").notNull().default(0),
    currentBalance: integer("current_balance").notNull().default(0),
    monthlyPrincipal: integer("monthly_principal").notNull().default(0),
    monthlyPayment: integer("monthly_payment").notNull().default(0),
    interestRate: real("interest_rate").notNull().default(0),
    maturityDate: text("maturity_date").notNull().default(""),
    scheduleUrl: text("schedule_url").notNull().default(""),
    memo: text("memo").notNull().default(""),
  },
  (t) => [index("idx_borrowings_maturity_date").on(t.maturityDate)],
);
export const contacts = sqliteTable(
  "contacts",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    date: text("date").notNull(),
    organization: text("organization").notNull(),
    person: text("person").notNull().default(""),
    method: text("method").notNull().default("電話"),
    content: text("content").notNull(),
    response: text("response").notNull().default(""),
    nextDate: text("next_date").notNull().default(""),
    waiting: integer("waiting", { mode: "boolean" }).notNull().default(false),
  },
  (t) => [index("idx_contacts_waiting_next").on(t.waiting, t.nextDate)],
);

export const caseMemos = sqliteTable(
  "case_memos",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    personName: text("person_name").notNull(),
    date: text("date").notNull(),
    title: text("title").notNull(),
    content: text("content").notNull(),
    nextAction: text("next_action").notNull().default(""),
    dueDate: text("due_date").notNull().default(""),
    priority: text("priority").notNull().default("中"),
    stage: text("stage").notNull().default("受付・対応中"),
    taskId: integer("task_id"),
  },
  (t) => [
    index("idx_case_memos_person_date").on(t.personName, t.date),
    index("idx_case_memos_task_id").on(t.taskId),
  ],
);

export const caseUpdates = sqliteTable(
  "case_updates",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    caseId: integer("case_id").notNull(),
    date: text("date").notNull(),
    stage: text("stage").notNull(),
    content: text("content").notNull(),
    nextAction: text("next_action").notNull().default(""),
    dueDate: text("due_date").notNull().default(""),
  },
  (t) => [
    index("idx_case_updates_case_date").on(t.caseId, t.date),
    index("idx_case_updates_stage").on(t.stage),
  ],
);

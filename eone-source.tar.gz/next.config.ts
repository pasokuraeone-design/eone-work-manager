import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  basePath: "/eone-work-manager",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;

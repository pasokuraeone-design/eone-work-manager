import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from "firebase/firestore";
import { db } from "./firebase";

const collectionNames = [
  "tasks",
  "candidates",
  "funds",
  "loans",
  "contacts",
  "cases",
  "caseUpdates",
  "projectDocuments",
  "borrowings",
] as const;

type CollectionName = (typeof collectionNames)[number];
type Row = Record<string, any> & { id: number };

const clean = (value: Record<string, unknown>) =>
  Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined));

const newId = () => Date.now() * 1000 + Math.floor(Math.random() * 1000);
const rowRef = (table: string, id: number) => doc(db, table, String(id));

async function readRow(table: string, id: number): Promise<Row | null> {
  const snapshot = await getDoc(rowRef(table, id));
  return snapshot.exists() ? (snapshot.data() as Row) : null;
}

export async function loadData() {
  const entries = await Promise.all(
    collectionNames.map(async (name) => {
      const snapshot = await getDocs(collection(db, name));
      const rows = snapshot.docs
        .map((item) => item.data() as Row)
        .sort((a, b) => Number(a.id) - Number(b.id));
      return [name, rows] as const;
    }),
  );
  return Object.fromEntries(entries);
}

export async function importSeed(seed: Record<string, Row[]>) {
  const allowed = new Set<string>(collectionNames);
  const entries = Object.entries(seed).filter(([name]) => allowed.has(name));
  let batch = writeBatch(db);
  let pending = 0;
  let imported = 0;
  for (const [name, rows] of entries) {
    for (const raw of rows) {
      const row = clean(raw) as Row;
      if (!row.id) continue;
      batch.set(rowRef(name, row.id), row);
      pending += 1;
      imported += 1;
      if (pending === 400) {
        await batch.commit();
        batch = writeBatch(db);
        pending = 0;
      }
    }
  }
  if (pending) await batch.commit();
  return imported;
}

function taskStatus(stage: string) {
  if (stage === "完了") return "完了";
  if (stage === "保留") return "保留";
  if (stage === "連絡済み・返信待ち") return "確認待ち";
  return "進行中";
}

function taskForCase(row: Row, id = newId()) {
  return {
    id,
    name: `${row.personName}｜${row.title}（ケース${row.id}）`,
    category: "利用者対応",
    scope: "ケース対応",
    dueDate: row.dueDate,
    assignee: "藤田",
    priority: row.priority,
    status: "未着手",
    memo: `ケースメモから作成\n${row.content}`,
    nextAction: row.nextAction,
    contact: "",
    resourceUrl: "",
    startMonth: row.dueDate?.slice(0, 7) || "",
    endMonth: row.dueDate?.slice(0, 7) || "",
  };
}

export async function dataRequest(method: string, body: any): Promise<any> {
  const { table, id, data = {} } = body as {
    table: CollectionName;
    id?: number;
    data?: Record<string, any>;
  };
  if (!collectionNames.includes(table)) throw new Error("保存先が正しくありません。");

  if (method === "POST") {
    if (table === "cases") {
      const caseId = newId();
      const { createTask, ...caseData } = data;
      let row: Row = { ...clean(caseData), id: caseId } as Row;
      const batch = writeBatch(db);
      let task: Row | undefined;
      if (createTask && row.nextAction && row.dueDate) {
        task = taskForCase(row);
        row = { ...row, taskId: task.id };
        batch.set(rowRef("tasks", task.id), task);
      }
      batch.set(rowRef("cases", caseId), row);
      await batch.commit();
      return { row, task };
    }

    if (table === "caseUpdates") {
      const updateId = newId();
      const row = { ...clean(data), id: updateId } as Row;
      const memo = await readRow("cases", row.caseId);
      if (!memo) throw new Error("対象のケース案件が見つかりません。");
      const caseRow: Row = {
        ...memo,
        stage: row.stage,
        nextAction: row.nextAction,
        dueDate: row.dueDate,
      };
      const batch = writeBatch(db);
      let task: Row | undefined;
      if (memo.taskId) {
        const currentTask = await readRow("tasks", memo.taskId);
        if (currentTask) {
          task = {
            ...currentTask,
            status: taskStatus(row.stage),
            nextAction: row.nextAction,
            dueDate: row.dueDate,
            startMonth: row.dueDate?.slice(0, 7) || "",
            endMonth: row.dueDate?.slice(0, 7) || "",
          };
          batch.set(rowRef("tasks", task.id), task);
        }
      } else if (row.nextAction && row.dueDate && row.stage !== "完了") {
        task = {
          ...taskForCase(memo),
          status: taskStatus(row.stage),
          nextAction: row.nextAction,
          dueDate: row.dueDate,
        };
        caseRow.taskId = task.id;
        batch.set(rowRef("tasks", task.id), task);
      }
      batch.set(rowRef("caseUpdates", updateId), row);
      batch.set(rowRef("cases", caseRow.id), caseRow);
      await batch.commit();
      return { row, case: caseRow, task };
    }

    const row = { ...clean(data), id: newId() } as Row;
    await setDoc(rowRef(table, row.id), row);
    return { row };
  }

  if (!id) throw new Error("対象が見つかりません。");

  if (method === "PATCH") {
    const current = await readRow(table, id);
    if (!current) throw new Error("対象の記録が見つかりません。");

    if (table === "tasks") {
      const row: Row = { ...current, ...clean(data), id };
      const batch = writeBatch(db);
      batch.set(rowRef(table, id), row);
      let caseRow: Row | undefined;
      if (typeof data.dueDate === "string") {
        const linked = await getDocs(
          query(collection(db, "cases"), where("taskId", "==", id)),
        );
        if (!linked.empty) {
          caseRow = {
            ...(linked.docs[0].data() as Row),
            dueDate: data.dueDate,
          };
          batch.set(rowRef("cases", caseRow.id), caseRow);
        }
      }
      await batch.commit();
      return { row, case: caseRow };
    }

    if (table === "cases") {
      const { taskStatus: nextTaskStatus, ...caseData } = data;
      const row: Row = { ...current, ...clean(caseData), id };
      const batch = writeBatch(db);
      batch.set(rowRef("cases", id), row);
      let task: Row | undefined;
      if (row.taskId) {
        const currentTask = await readRow("tasks", row.taskId);
        if (currentTask) {
          task = {
            ...currentTask,
            name: `${row.personName}｜${row.title}（ケース${row.id}）`,
            dueDate: row.dueDate,
            priority: row.priority,
            memo: `ケースメモから作成\n${row.content}`,
            nextAction: row.nextAction,
            startMonth: row.dueDate?.slice(0, 7) || "",
            endMonth: row.dueDate?.slice(0, 7) || "",
            ...(typeof nextTaskStatus === "string"
              ? { status: nextTaskStatus }
              : {}),
          };
          batch.set(rowRef("tasks", task.id), task);
        }
      }
      await batch.commit();
      return { row, task };
    }

    const row: Row = { ...current, ...clean(data), id };
    await updateDoc(rowRef(table, id), clean(data));
    return { row };
  }

  if (method === "DELETE") {
    if (table === "cases") {
      const memo = await readRow("cases", id);
      const updates = await getDocs(
        query(collection(db, "caseUpdates"), where("caseId", "==", id)),
      );
      const batch = writeBatch(db);
      updates.docs.forEach((item) => batch.delete(item.ref));
      if (memo?.taskId) batch.delete(rowRef("tasks", memo.taskId));
      batch.delete(rowRef("cases", id));
      await batch.commit();
      return { ok: true, deletedTaskId: memo?.taskId ?? null };
    }
    await deleteDoc(rowRef(table, id));
    return { ok: true, deletedTaskId: null };
  }

  throw new Error("未対応の操作です。");
}

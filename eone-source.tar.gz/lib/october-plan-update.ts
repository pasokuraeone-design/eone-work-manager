import { sql } from "drizzle-orm";
import { getDb } from "../db";

// Apply the requested progress update atomically once; later user edits/deletions remain intact.
export async function applyOctoberPlanUpdate() {
  const db = getDb();
  await db.batch([
    db.run(sql.raw("INSERT INTO project_documents (title,category,summary,key_numbers,updated_date,drive_url,related_task_ids) SELECT '新棟の平面図｜2026年10月22日 検討プラン（A・B案）','建物・図面','グリーンホーム・アドバンス株式会社作成。1階平面図と2階のA・B案を掲載した検討段階のプラン。今後この図面をもとに相談・調整を進める。確定図面ではない。1階はLDK・事務室兼仮眠スペース・水回り、2階は各案とも洋室4室。B案の一部居室はオープンクローゼット込みの表記。面積の扱い等は設計者・行政へ確認する。敷地形状・寸法は概略で、測量等による確認が必要。9月版は履歴として保存。','木造2階建て／延床面積86.11㎡（1階39.74㎡・2階46.37㎡）／LDK19.87㎡（12帖）／事務室4.14㎡（2.5帖）／駐車場2台／居室4室（図面記載8.28〜9.11㎡）','2026-10-22','https://drive.google.com/file/d/1ocCHl-QrxBN_qt67jEJ-JeE4zNR3aenf/view?usp=drivesdk','3,4,41' WHERE NOT EXISTS (SELECT 1 FROM project_update_log WHERE key = 'yamate-plan-2026-10-23') AND NOT EXISTS (SELECT 1 FROM project_documents WHERE drive_url = 'https://drive.google.com/file/d/1ocCHl-QrxBN_qt67jEJ-JeE4zNR3aenf/view?usp=drivesdk')")),
    db.run(sql.raw("INSERT INTO contacts (date,organization,person,method,content,response,next_date,waiting) SELECT '2026-10-23','新棟計画／グループLINE','','LINE','【10月23日・藤田さんからの報告として記録／LINE原文未確認】10月22日付の新棟検討プラン（1階・2階A/B案）ができた。今後はこの図面をもとに検討を進め、資料の送付や打ち合わせのやり取りはグループLINEで行う予定。','図面をGoogle Driveの「山手新棟｜LINE共有資料」に保存。今後はLINEで届いた資料とやり取りのスクリーンショット・メモを同フォルダに日付付きで保存し、必要時にチャッピーへ確認を依頼する。アプリの自動同期ではない。','',0 WHERE NOT EXISTS (SELECT 1 FROM project_update_log WHERE key = 'yamate-plan-2026-10-23')")),
    db.run(sql.raw("UPDATE tasks SET memo = memo || '\n\n【2026年10月23日 進捗】\n10月22日付の新棟検討プラン（1階・2階A/B案）ができた。今後この図面をもとに検討を進める。資料の送付・打ち合わせのやり取りはグループLINEで行う予定。資料はGoogle Drive「山手新棟｜LINE共有資料」に保存。\n大家側融資の正式承認について今回新たな報告はなく、未確認のまま。', next_action = '10月22日付のA・B案を比較し、居室・収納・職員スペース等の希望と確認事項を整理してグループLINEで相談する。大家側融資の正式承認状況も引き続き確認する。', status='進行中' WHERE id=41 AND NOT EXISTS (SELECT 1 FROM project_update_log WHERE key = 'yamate-plan-2026-10-23')")),
    db.run(sql.raw("UPDATE tasks SET next_action='10月22日付の検討プラン（A・B案）をもとに、県への事前相談事項を整理して相談する。', resource_url='https://drive.google.com/file/d/1ocCHl-QrxBN_qt67jEJ-JeE4zNR3aenf/view?usp=drivesdk' WHERE id=3 AND next_action='大家から最新図面を受領' AND NOT EXISTS (SELECT 1 FROM project_update_log WHERE key = 'yamate-plan-2026-10-23')")),
    db.run(sql.raw("INSERT INTO project_update_log (key) VALUES ('yamate-plan-2026-10-23') ON CONFLICT DO NOTHING")),
  ]);
}


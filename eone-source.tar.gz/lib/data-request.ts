export { dataRequest } from "./firestore-data";

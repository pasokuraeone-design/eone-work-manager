export const contactMethods = ["電話", "メール", "LINE", "訪問"];
const tableNames = ["tasks", "candidates", "funds", "loans", "contacts", "cases", "caseUpdates", "projectDocuments", "borrowings"];

export function mutationError(body: any, method: "POST" | "PATCH" | "DELETE"): string | null {
  if (!body || !tableNames.includes(body.table)) return "保存先が正しくありません。";
  if (method !== "POST" && (!Number.isSafeInteger(body.id) || body.id < 1))
    return "対象のIDが正しくありません。";
  if (method === "DELETE") return null;
  const data = body.data;
  if (!data || typeof data !== "object" || Array.isArray(data) || !Object.keys(data).length)
    return "保存する内容がありません。";
  if ("id" in data) return "IDは変更できません。";
  if (body.table === "tasks") {
    if ((method === "POST" || "name" in data) && (typeof data.name !== "string" || !data.name.trim()))
      return "タスク名を入力してください。";
    for (const key of ["name", "memo", "nextAction", "dueDate", "startMonth", "endMonth"])
      if (key in data && typeof data[key] !== "string") return "入力内容の形式が正しくありません。";
    for (const key of ["startMonth", "endMonth"])
      if (data[key] && !/^\d{4}-(0[1-9]|1[0-2])$/.test(data[key])) return "開始月・終了月を正しく入力してください。";
    if (data.startMonth && data.endMonth && data.startMonth > data.endMonth)
      return "終了月は開始月以降にしてください。";
  }
  if (body.table === "contacts") {
    if ("method" in data && !contactMethods.includes(data.method)) return "連絡方法を選択してください。";
    for (const key of ["date", "organization", "content"])
      if ((method === "POST" || key in data) && (typeof data[key] !== "string" || !data[key].trim()))
        return "日付・相手・内容を入力してください。";
  }
  return null;
}

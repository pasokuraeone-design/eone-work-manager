import { getApp, getApps, initializeApp } from "firebase/app";
import {
  GoogleAuthProvider,
  getAuth,
  signInWithPopup,
  signOut,
} from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCbSv8ZVwsN4rjb49vuOa7LN8aT_rG923g",
  authDomain: "eone-work-manager.firebaseapp.com",
  projectId: "eone-work-manager",
  storageBucket: "eone-work-manager.firebasestorage.app",
  messagingSenderId: "150419550957",
  appId: "1:150419550957:web:a18df4b8d9c264a58952e4",
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const allowedEmail = "pasokuraeone@gmail.com";

export async function loginWithGoogle() {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });
  const result = await signInWithPopup(auth, provider);
  if (result.user.email !== allowedEmail) {
    await signOut(auth);
    throw new Error("このGoogleアカウントにはアクセス権がありません。");
  }
  return result.user;
}

export function logout() {
  return signOut(auth);
}

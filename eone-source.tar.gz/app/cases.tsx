"use client";

import { useMemo, useRef, useState } from "react";
import {
  CalendarDays,
  CheckCircle2,
  CircleDot,
  History,
  ListTodo,
  Loader2,
  NotebookPen,
  Pencil,
  Plus,
  Search,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type CaseMemo = {
  id: number;
  personName: string;
  date: string;
  title: string;
  content: string;
  nextAction: string;
  dueDate: string;
  priority: string;
  stage: string;
  taskId: number | null;
};
type CaseUpdate = {
  id: number;
  caseId: number;
  date: string;
  stage: string;
  content: string;
  nextAction: string;
  dueDate: string;
};
type Task = { id: number; name: string; status: string };
type Props = {
  rows: CaseMemo[];
  updates: CaseUpdate[];
  tasks: Task[];
  create: (table: string, values: Record<string, unknown>) => Promise<boolean>;
  patch: (table: string, id: number, values: Record<string, unknown>) => Promise<boolean>;
  remove: (table: string, id: number) => Promise<boolean>;
};

const stages = [
  "未着手",
  "受付・対応中",
  "連絡済み・返信待ち",
  "日程確定",
  "実施待ち",
  "記録待ち",
  "完了",
  "保留",
];
const today = () =>
  new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Tokyo" }).format(new Date());
const fmt = (s: string) => (s ? `${+s.slice(5, 7)}/${+s.slice(8, 10)}` : "—");
const nextStage = (stage: string) =>
  ({
    未着手: "受付・対応中",
    "受付・対応中": "連絡済み・返信待ち",
    "連絡済み・返信待ち": "日程確定",
    日程確定: "実施待ち",
    実施待ち: "記録待ち",
    記録待ち: "完了",
    保留: "受付・対応中",
    完了: "完了",
  })[stage] || "受付・対応中";

export function Cases({ rows, updates, tasks, create, patch, remove }: Props) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("すべて");
  const taskMap = useMemo(() => new Map(tasks.map((t) => [t.id, t])), [tasks]);
  const updatesByCase = useMemo(() => {
    const grouped = new Map<number, CaseUpdate[]>();
    for (const update of updates) {
      const list = grouped.get(update.caseId) || [];
      list.push(update);
      grouped.set(update.caseId, list);
    }
    for (const list of grouped.values())
      list.sort((a, b) => a.date.localeCompare(b.date) || a.id - b.id);
    return grouped;
  }, [updates]);
  const people = new Set(rows.map((r) => r.personName)).size;
  const active = rows.filter((r) => r.stage !== "完了" && r.stage !== "保留").length;
  const shown = [...rows]
    .filter((r) => {
      const history = (updatesByCase.get(r.id) || [])
        .map((u) => `${u.stage}${u.content}${u.nextAction}`)
        .join("");
      const matches =
        !q ||
        `${r.personName}${r.title}${r.content}${r.nextAction}${history}`
          .toLowerCase()
          .includes(q.toLowerCase());
      const matchesFilter =
        filter === "すべて" ||
        (filter === "対応中" && r.stage !== "完了" && r.stage !== "保留") ||
        (filter === "返信待ち" && r.stage === "連絡済み・返信待ち") ||
        (filter === "完了" && r.stage === "完了") ||
        (filter === "保留" && r.stage === "保留");
      return matches && matchesFilter;
    })
    .sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);

  return (
    <div className="space-y-5">
      <section className="rounded-[24px] bg-gradient-to-br from-[#7a3048] to-[#c45572] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-bold text-rose-100">利用者さんごとに、最初から完了まで</p>
            <h2 className="mt-1 text-2xl font-black sm:text-3xl">ケース案件</h2>
            <p className="mt-2 max-w-2xl text-sm text-rose-50">
              連絡、日程決定、実施、記録を同じ案件に時系列で残せます。次にすることは1件のタスクとして更新されます。
            </p>
          </div>
          <AddCase create={create} />
        </div>
      </section>

      <div className="grid grid-cols-3 gap-3">
        <Metric icon={NotebookPen} label="案件" value={`${rows.length}件`} />
        <Metric icon={UserRound} label="利用者" value={`${people}名`} />
        <Metric icon={ListTodo} label="対応中" value={`${active}件`} accent />
      </div>

      <div className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 text-slate-400" size={18} />
          <Input
            className="h-11 bg-white pl-10"
            placeholder="利用者名・案件名・経過で検索"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <select
          className="h-11 rounded-xl border bg-white px-3 font-semibold"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          {["すべて", "対応中", "返信待ち", "完了", "保留"].map((x) => (
            <option key={x}>{x}</option>
          ))}
        </select>
      </div>

      <div className="space-y-4">
        {shown.map((row) => (
          <CaseCard
            key={row.id}
            row={row}
            updates={updatesByCase.get(row.id) || []}
            task={row.taskId ? taskMap.get(row.taskId) : undefined}
            create={create}
            patch={patch}
            remove={remove}
          />
        ))}
        {!shown.length && (
          <div className="rounded-2xl border border-dashed bg-white py-16 text-center">
            <NotebookPen className="mx-auto text-slate-300" size={40} />
            <p className="mt-3 font-bold text-slate-500">該当するケース案件はありません</p>
          </div>
        )}
      </div>
    </div>
  );
}

function CaseCard({
  row,
  updates,
  task,
  create,
  patch,
  remove,
}: {
  row: CaseMemo;
  updates: CaseUpdate[];
  task?: Task;
  create: Props["create"];
  patch: Props["patch"];
  remove: Props["remove"];
}) {
  const done = row.stage === "完了";
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-blue-50 px-3 py-1 text-sm font-black text-blue-700">
              {row.personName}
            </span>
            <span className="text-sm font-bold text-slate-500">開始 {fmt(row.date)}</span>
          </div>
          <h3 className="mt-2 text-lg font-black sm:text-xl">{row.title}</h3>
        </div>
        <StageBadge stage={row.stage} />
      </div>

      <div className="mt-5 border-l-2 border-rose-100 pl-4">
        <p className="text-xs font-black tracking-wide text-slate-400">最初の記録</p>
        <p className="mt-1 whitespace-pre-wrap leading-7 text-slate-700">{row.content}</p>
      </div>

      {!!updates.length && (
        <div className="mt-5 rounded-2xl bg-slate-50 p-4">
          <div className="mb-3 flex items-center gap-2 font-black text-slate-700">
            <History size={18} className="text-rose-600" />
            これまでの経過
          </div>
          <div className="space-y-4 border-l-2 border-slate-200 pl-4">
            {updates.map((update) => (
              <div key={update.id} className="relative">
                <span className="absolute -left-[22px] top-1.5 h-3 w-3 rounded-full border-2 border-white bg-rose-500" />
                <div className="flex flex-wrap items-center gap-2">
                  <b className="text-sm">{fmt(update.date)}</b>
                  <span className="rounded-full bg-white px-2.5 py-1 text-xs font-black text-slate-600 shadow-sm">
                    {update.stage}
                  </span>
                </div>
                <p className="mt-1 whitespace-pre-wrap leading-6 text-slate-700">{update.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {(row.nextAction || row.dueDate) && !done && (
        <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-black tracking-wide text-slate-500">今、次にすること</p>
            {task && (
              <span className={`rounded-full px-2.5 py-1 text-xs font-black ${task.status === "完了" ? "bg-emerald-100 text-emerald-800" : "bg-white text-slate-700"}`}>
                {task.status}
              </span>
            )}
          </div>
          <div className="mt-1 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <b>{row.nextAction || "次の対応を確認"}</b>
            <span className="inline-flex items-center gap-1 text-sm font-bold text-slate-600">
              <CalendarDays size={16} />
              {row.dueDate ? `${fmt(row.dueDate)}まで` : "期限未設定"}
            </span>
          </div>
        </div>
      )}

      <div className="mt-4 flex flex-wrap justify-end gap-2 border-t pt-3">
        <EditCase row={row} task={task} patch={patch} remove={remove} />
        <AddUpdate row={row} task={task} create={create} />
      </div>
    </article>
  );
}

function StageBadge({ stage }: { stage: string }) {
  const done = stage === "完了";
  const waiting = stage === "連絡済み・返信待ち";
  const hold = stage === "保留";
  return (
    <span
      className={`inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1 text-sm font-bold ${
        done
          ? "bg-emerald-50 text-emerald-700"
          : waiting
            ? "bg-amber-50 text-amber-800"
            : hold
              ? "bg-slate-100 text-slate-600"
              : "bg-blue-50 text-blue-700"
      }`}
    >
      {done ? <CheckCircle2 size={16} /> : <CircleDot size={16} />}
      {stage}
    </span>
  );
}

function Metric({ icon: Icon, label, value, accent = false }: {
  icon: any; label: string; value: string; accent?: boolean;
}) {
  return (
    <div className="rounded-2xl border bg-white p-3 shadow-sm sm:p-4">
      <Icon className={accent ? "text-amber-600" : "text-blue-600"} size={20} />
      <p className="mt-2 text-xl font-black sm:text-2xl">{value}</p>
      <p className="text-xs font-bold text-slate-500 sm:text-sm">{label}</p>
    </div>
  );
}

function AddUpdate({ row, task, create }: {
  row: CaseMemo; task?: Task; create: Props["create"];
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const fresh = () => ({
    date: today(),
    stage: nextStage(row.stage),
    content: "",
    nextAction: "",
    dueDate: "",
  });
  const [v, setV] = useState(fresh);
  const changeOpen = (next: boolean) => {
    if (saving) return;
    if (next) setV(fresh());
    setOpen(next);
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await create("caseUpdates", {
        caseId: row.id,
        date: v.date,
        stage: v.stage,
        content: v.content,
        nextAction: v.stage === "完了" ? "" : v.nextAction,
        dueDate: v.stage === "完了" ? "" : v.dueDate,
      })) setOpen(false);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={changeOpen}>
      <DialogTrigger asChild>
        <Button className="h-10 bg-[#b94363] font-black hover:bg-[#9f3653]">
          <Plus size={17} />経過を追加
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-xl">
        <DialogHeader className="border-b px-5 py-4">
          <DialogTitle className="text-xl">{row.personName}さんの経過を追加</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="max-h-[calc(94dvh-4.5rem)] space-y-4 overflow-y-auto px-5 pb-3">
          <div className="rounded-xl bg-rose-50 p-3">
            <p className="text-xs font-bold text-rose-700">案件</p><b>{row.title}</b>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Label text="日付">
              <Input required type="date" value={v.date} onChange={(e) => setV({ ...v, date: e.target.value })} />
            </Label>
            <Label text="現在の段階">
              <select className="h-10 w-full rounded-lg border bg-white px-3" value={v.stage} onChange={(e) => setV({ ...v, stage: e.target.value })}>
                {stages.map((x) => <option key={x}>{x}</option>)}
              </select>
            </Label>
          </div>
          <Label text="今回あったこと・したこと">
            <Textarea required autoFocus className="min-h-28" placeholder="例：田口さんへ連絡済み。現在、候補日の返信待ち。" value={v.content} onChange={(e) => setV({ ...v, content: e.target.value })} />
          </Label>
          {v.stage !== "完了" ? (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
              <p className="font-black">ここから次にすること</p>
              <div className="mt-3 space-y-3">
                <Input placeholder="例：先方からの返信を待つ" value={v.nextAction} onChange={(e) => setV({ ...v, nextAction: e.target.value })} />
                <Label text="次に確認する期限（未定なら空欄でOK）">
                  <Input type="date" value={v.dueDate} onChange={(e) => setV({ ...v, dueDate: e.target.value })} />
                </Label>
                {task && <p className="text-sm font-bold text-amber-800">同じタスクの状態・次の行動・期限が更新されます。</p>}
              </div>
            </div>
          ) : (
            <p className="rounded-xl bg-emerald-50 p-3 text-sm font-bold text-emerald-800">
              完了にすると、連動しているタスクも完了になります。経過はそのまま残ります。
            </p>
          )}
          <SaveBar saving={saving} label="経過を保存" />
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AddCase({ create }: { create: Props["create"] }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const fresh = () => ({
    personName: "", date: today(), title: "", content: "", nextAction: "",
    dueDate: "", priority: "中", makeTask: true,
  });
  const [v, setV] = useState(fresh);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await create("cases", {
        personName: v.personName, date: v.date, title: v.title, content: v.content,
        nextAction: v.nextAction, dueDate: v.dueDate, priority: v.priority,
        stage: "未着手", createTask: v.makeTask,
      })) {
        setV(fresh());
        setOpen(false);
      }
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => !saving && setOpen(next)}>
      <DialogTrigger asChild>
        <Button className="h-12 shrink-0 bg-white px-5 text-base font-black text-[#a33e5a] shadow-lg hover:bg-rose-50">
          <Plus />ケース案件を追加
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle className="text-xl">ケース案件を追加</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="max-h-[calc(94dvh-4.5rem)] space-y-4 overflow-y-auto px-5 pb-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <Label text="利用者名"><Input required autoFocus placeholder="例：りきくん" value={v.personName} onChange={(e) => setV({ ...v, personName: e.target.value })} /></Label>
            <Label text="開始日"><Input required type="date" value={v.date} onChange={(e) => setV({ ...v, date: e.target.value })} /></Label>
          </div>
          <Label text="案件名"><Input required placeholder="例：モニタリング日程調整" value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} /></Label>
          <Label text="最初の経緯・内容"><Textarea required className="min-h-32" placeholder="依頼されたこと、分かったこと、相手がしてくれることなど" value={v.content} onChange={(e) => setV({ ...v, content: e.target.value })} /></Label>
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
            <label className="flex min-h-11 items-center gap-3 font-black">
              <input className="h-6 w-6" type="checkbox" checked={v.makeTask} onChange={(e) => setV({ ...v, makeTask: e.target.checked })} />
              次にすることをタスクへ追加
            </label>
            {v.makeTask && (
              <div className="mt-3 space-y-3">
                <Label text="次にすること"><Input required placeholder="例：相談員へ候補日を連絡" value={v.nextAction} onChange={(e) => setV({ ...v, nextAction: e.target.value })} /></Label>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Label text="期限"><Input required type="date" value={v.dueDate} onChange={(e) => setV({ ...v, dueDate: e.target.value })} /></Label>
                  <Label text="優先度">
                    <select className="h-10 w-full rounded-lg border bg-white px-3" value={v.priority} onChange={(e) => setV({ ...v, priority: e.target.value })}>
                      {["低", "中", "高", "最優先"].map((x) => <option key={x}>{x}</option>)}
                    </select>
                  </Label>
                </div>
              </div>
            )}
          </div>
          <SaveBar saving={saving} label="案件を保存" />
        </form>
      </DialogContent>
    </Dialog>
  );
}

function EditCase({ row, task, patch, remove }: {
  row: CaseMemo; task?: Task; patch: Props["patch"]; remove: Props["remove"];
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const fresh = () => ({ ...row, taskStatus: task?.status || "未着手" });
  const [v, setV] = useState(fresh);
  const changeOpen = (next: boolean) => {
    if (saving) return;
    if (next) setV(fresh());
    setOpen(next);
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await patch("cases", row.id, {
        personName: v.personName, date: v.date, title: v.title, content: v.content,
        nextAction: v.nextAction, dueDate: v.dueDate, priority: v.priority,
        taskStatus: v.taskStatus,
      })) setOpen(false);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  const del = async () => {
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try { if (await remove("cases", row.id)) setOpen(false); }
    finally { savingRef.current = false; setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={changeOpen}>
      <DialogTrigger asChild><Button variant="outline" className="h-10 font-bold"><Pencil size={16} />案件を編集</Button></DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle className="text-xl">ケース案件を編集</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="max-h-[calc(94dvh-4.5rem)] space-y-4 overflow-y-auto px-5 pb-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <Label text="利用者名"><Input required value={v.personName} onChange={(e) => setV({ ...v, personName: e.target.value })} /></Label>
            <Label text="開始日"><Input required type="date" value={v.date} onChange={(e) => setV({ ...v, date: e.target.value })} /></Label>
          </div>
          <Label text="案件名"><Input required value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} /></Label>
          <Label text="最初の経緯・内容"><Textarea required className="min-h-32" value={v.content} onChange={(e) => setV({ ...v, content: e.target.value })} /></Label>
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="font-black">現在の次にすること</p>
              {task && (
                <span className={`rounded-full px-3 py-1 text-sm font-black ${v.taskStatus === "完了" ? "bg-emerald-100 text-emerald-800" : "bg-white text-slate-700"}`}>
                  {v.taskStatus}
                </span>
              )}
            </div>
            <div className="mt-3 space-y-3">
              <Input placeholder="なければ空欄でもOK" value={v.nextAction} onChange={(e) => setV({ ...v, nextAction: e.target.value })} />
              <div className={`grid gap-3 ${task ? "sm:grid-cols-3" : "sm:grid-cols-2"}`}>
                <Label text="期限"><Input type="date" value={v.dueDate} onChange={(e) => setV({ ...v, dueDate: e.target.value })} /></Label>
                <Label text="優先度">
                  <select className="h-10 w-full rounded-lg border bg-white px-3" value={v.priority} onChange={(e) => setV({ ...v, priority: e.target.value })}>
                    {["低", "中", "高", "最優先"].map((x) => <option key={x}>{x}</option>)}
                  </select>
                </Label>
                {task && (
                  <Label text="状態">
                    <select className={`h-10 w-full rounded-lg border px-3 font-bold ${v.taskStatus === "完了" ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "bg-white"}`} value={v.taskStatus} onChange={(e) => setV({ ...v, taskStatus: e.target.value })}>
                      {["未着手", "進行中", "確認待ち", "完了", "保留"].map((x) => <option key={x}>{x}</option>)}
                    </select>
                  </Label>
                )}
              </div>
              {row.taskId && <p className="text-sm font-bold text-amber-800">変更内容は、連動している同じタスクにも反映されます。</p>}
            </div>
          </div>
          <div className="sticky bottom-0 -mx-5 flex gap-2 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
            <AlertDialog>
              <AlertDialogTrigger asChild><Button type="button" variant="outline" disabled={saving} className="h-12 border-red-200 px-4 text-red-600">削除</Button></AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>このケース案件を削除しますか？</AlertDialogTitle>
                  <AlertDialogDescription>経過記録と、案件から作られたタスクも一緒に削除されます。</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>キャンセル</AlertDialogCancel>
                  <AlertDialogAction onClick={del} className="bg-red-600 hover:bg-red-700">削除する</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button type="submit" disabled={saving} className="h-12 flex-1 bg-blue-600 text-base font-black shadow-lg">
              {saving && <Loader2 className="animate-spin" />}{saving ? "保存中…" : "変更を保存"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function SaveBar({ saving, label }: { saving: boolean; label: string }) {
  return (
    <div className="sticky bottom-0 -mx-5 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
      <Button type="submit" disabled={saving} className="h-12 w-full bg-blue-600 text-base font-black shadow-lg">
        {saving && <Loader2 className="animate-spin" />}{saving ? "保存中…" : label}
      </Button>
    </div>
  );
}

function Label({ text, children }: { text: string; children: React.ReactNode }) {
  return <label className="block text-sm font-bold">{text}<div className="mt-1">{children}</div></label>;
}

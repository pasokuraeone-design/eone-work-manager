"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Banknote,
  ExternalLink,
  FileText,
  FolderOpen,
  Landmark,
  Loader2,
  Pencil,
  Plus,
  Search,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export type ProjectDocument = {
  id: number;
  title: string;
  category: string;
  summary: string;
  keyNumbers: string;
  updatedDate: string;
  driveUrl: string;
  relatedTaskIds: string;
};

export type Borrowing = {
  id: number;
  lender: string;
  originalAmount: number;
  currentBalance: number;
  monthlyPrincipal: number;
  monthlyPayment: number;
  interestRate: number;
  maturityDate: string;
  scheduleUrl: string;
  memo: string;
};

type Task = { id: number; name: string; scope: string };
type Props = {
  documents: ProjectDocument[];
  borrowings: Borrowing[];
  tasks: Task[];
  focusId: number | null;
  create: (table: string, values: Record<string, unknown>) => Promise<boolean>;
  patch: (table: string, id: number, values: Record<string, unknown>) => Promise<boolean>;
  remove: (table: string, id: number) => Promise<boolean>;
};

export const documentCategories = [
  "銀行・融資",
  "決算・売上",
  "入居者・稼働実績",
  "建物・図面",
  "行政・指定",
  "契約・覚書",
  "その他",
];

export const linkedTaskIds = (value: string) =>
  value
    .split(",")
    .map((x) => Number(x))
    .filter((x) => Number.isFinite(x) && x > 0);

const yen = (n: number) =>
  new Intl.NumberFormat("ja-JP", {
    style: "currency",
    currency: "JPY",
    maximumFractionDigits: 0,
  }).format(n || 0);
const fmtDate = (s: string) => (s ? s.replaceAll("-", "/") : "未設定");
const safeUrl = (value: string) => {
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.toString() : "";
  } catch {
    return "";
  }
};

export function Documents({
  documents,
  borrowings,
  tasks,
  focusId,
  create,
  patch,
  remove,
}: Props) {
  const [tab, setTab] = useState("documents");
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("すべて");
  const taskMap = useMemo(() => new Map(tasks.map((t) => [t.id, t.name])), [tasks]);
  const projectTasks = tasks.filter((t) => t.scope === "新棟オープン");
  const shown = documents
    .filter(
      (d) =>
        (category === "すべて" || d.category === category) &&
        (!q || `${d.title}${d.summary}${d.keyNumbers}`.toLowerCase().includes(q.toLowerCase())),
    )
    .sort((a, b) => (b.updatedDate || "").localeCompare(a.updatedDate || "") || b.id - a.id);

  useEffect(() => {
    if (!focusId) return;
    setTab("documents");
    const timer = window.setTimeout(() => {
      document.getElementById(`project-document-${focusId}`)?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 100);
    return () => window.clearTimeout(timer);
  }, [focusId]);

  return (
    <div className="space-y-5">
      <section className="rounded-[24px] bg-gradient-to-br from-[#315a8c] to-[#597db5] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-bold text-blue-100">Google Driveを原本置き場に</p>
            <h2 className="mt-1 text-2xl font-black sm:text-3xl">資料・データ</h2>
            <p className="mt-2 max-w-2xl text-sm text-blue-50">
              資料の要点と重要な数字をここで確認し、原本はGoogle Driveで開けます。
            </p>
          </div>
          <FolderOpen className="hidden text-blue-100 sm:block" size={58} />
        </div>
      </section>

      <section className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
        <h3 className="font-black text-blue-950">山手新棟｜LINE共有資料</h3>
        <p className="mt-2 text-sm leading-6 text-slate-700">グループLINEで届いた図面・見積り・打ち合わせのスクリーンショットやメモを保存するフォルダです。日付を付けて保存し、旧版も残します。保存後、チャッピーに確認を依頼してください。自動同期ではありません。</p>
        <a href="https://drive.google.com/drive/folders/16C710kgy0PNDXPie5Wwr-bBa8XOR0OPS" target="_blank" rel="noreferrer" className="mt-3 inline-flex min-h-11 items-center gap-2 rounded-xl bg-blue-600 px-4 font-bold text-white"><FolderOpen size={18} />共有資料フォルダを開く</a>
      </section>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid h-12 w-full grid-cols-2 bg-white sm:w-[420px]">
          <TabsTrigger value="documents" className="font-black">
            <FileText />資料庫
          </TabsTrigger>
          <TabsTrigger value="borrowings" className="font-black">
            <Landmark />借入金一覧
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="mt-5 space-y-4">
          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 text-slate-400" size={18} />
              <Input
                className="h-11 bg-white pl-10"
                placeholder="資料名・要約・数字で検索"
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
            </div>
            <select
              className="h-11 rounded-xl border bg-white px-3 font-semibold"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {["すべて", ...documentCategories].map((x) => <option key={x}>{x}</option>)}
            </select>
            <DocumentDialog tasks={projectTasks} create={create} />
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            {shown.map((doc) => (
              <article
                id={`project-document-${doc.id}`}
                key={doc.id}
                className={`scroll-mt-24 rounded-2xl border bg-white p-5 shadow-sm transition ${focusId === doc.id ? "border-blue-500 ring-4 ring-blue-100" : "border-slate-200"}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="rounded-full bg-blue-50 px-3 py-1 text-sm font-black text-blue-700">
                      {doc.category}
                    </span>
                    <h3 className="mt-3 text-xl font-black">{doc.title}</h3>
                  </div>
                  <EditDocument row={doc} tasks={projectTasks} patch={patch} remove={remove} />
                </div>
                {doc.summary && <p className="mt-3 whitespace-pre-wrap leading-7 text-slate-700">{doc.summary}</p>}
                {doc.keyNumbers && (
                  <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3">
                    <p className="text-xs font-black tracking-wide text-amber-800">重要な数字</p>
                    <p className="mt-1 whitespace-pre-wrap font-bold">{doc.keyNumbers}</p>
                  </div>
                )}
                {!!linkedTaskIds(doc.relatedTaskIds).length && (
                  <div className="mt-4">
                    <p className="text-xs font-black text-slate-500">関連タスク</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {linkedTaskIds(doc.relatedTaskIds).map((id) => (
                        <span key={id} className="rounded-full bg-slate-100 px-3 py-1 text-sm font-bold text-slate-700">
                          {taskMap.get(id) || `タスク ${id}`}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <div className="mt-5 flex flex-col gap-3 border-t pt-4 sm:flex-row sm:items-center sm:justify-between">
                  <span className="text-sm font-semibold text-slate-500">更新日 {fmtDate(doc.updatedDate)}</span>
                  {safeUrl(doc.driveUrl) ? (
                    <a
                      href={safeUrl(doc.driveUrl)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 font-black text-white hover:bg-blue-700"
                    >
                      <ExternalLink size={18} />Google Driveで開く
                    </a>
                  ) : (
                    <span className="text-sm font-bold text-red-600">Driveリンク未設定</span>
                  )}
                </div>
              </article>
            ))}
            {!shown.length && (
              <div className="rounded-2xl border border-dashed bg-white py-16 text-center xl:col-span-2">
                <FileText className="mx-auto text-slate-300" size={40} />
                <p className="mt-3 font-bold text-slate-500">該当する資料はありません</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="borrowings" className="mt-5">
          <BorrowingList rows={borrowings} create={create} patch={patch} remove={remove} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function freshDocument() {
  return {
    title: "",
    category: documentCategories[0],
    summary: "",
    keyNumbers: "",
    updatedDate: new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Tokyo" }).format(new Date()),
    driveUrl: "",
    relatedTaskIds: "",
  };
}

function DocumentDialog({ tasks, create }: { tasks: Task[]; create: Props["create"] }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [v, setV] = useState(freshDocument);
  const savingRef = useRef(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await create("projectDocuments", v)) {
        setV(freshDocument());
        setOpen(false);
      }
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => !saving && setOpen(next)}>
      <DialogTrigger asChild>
        <Button className="h-11 bg-blue-600 font-black"><Plus />資料を追加</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-2xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle>資料を追加</DialogTitle></DialogHeader>
        <DocumentForm v={v} setV={setV} tasks={tasks} submit={submit} saving={saving} saveLabel="資料を保存" />
      </DialogContent>
    </Dialog>
  );
}

function EditDocument({ row, tasks, patch, remove }: {
  row: ProjectDocument;
  tasks: Task[];
  patch: Props["patch"];
  remove: Props["remove"];
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [v, setV] = useState({ ...row });
  const savingRef = useRef(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await patch("projectDocuments", row.id, v)) setOpen(false);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  const del = async () => {
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await remove("projectDocuments", row.id)) setOpen(false);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (saving) return;
        if (next) setV({ ...row });
        setOpen(next);
      }}
    >
      <DialogTrigger asChild><Button variant="outline" className="h-10 font-bold"><Pencil size={16} />編集</Button></DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-2xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle>資料を編集</DialogTitle></DialogHeader>
        <DocumentForm v={v} setV={setV} tasks={tasks} submit={submit} saving={saving} saveLabel="変更を保存" onDelete={del} />
      </DialogContent>
    </Dialog>
  );
}

function DocumentForm({ v, setV, tasks, submit, saving, saveLabel, onDelete }: {
  v: Omit<ProjectDocument, "id"> | ProjectDocument;
  setV: (value: any) => void;
  tasks: Task[];
  submit: (e: React.FormEvent) => void;
  saving: boolean;
  saveLabel: string;
  onDelete?: () => void;
}) {
  const selected = new Set(linkedTaskIds(v.relatedTaskIds));
  const toggleTask = (id: number) => {
    if (selected.has(id)) selected.delete(id);
    else selected.add(id);
    setV({ ...v, relatedTaskIds: [...selected].sort((a, b) => a - b).join(",") });
  };
  return (
    <form onSubmit={submit} className="max-h-[calc(94dvh-4.5rem)] space-y-4 overflow-y-auto px-5 pb-3">
      <Label text="資料名"><Input required autoFocus value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} /></Label>
      <div className="grid gap-3 sm:grid-cols-2">
        <Label text="カテゴリ">
          <select className="h-11 w-full rounded-lg border bg-white px-3" value={v.category} onChange={(e) => setV({ ...v, category: e.target.value })}>
            {documentCategories.map((x) => <option key={x}>{x}</option>)}
          </select>
        </Label>
        <Label text="更新日"><Input required type="date" value={v.updatedDate} onChange={(e) => setV({ ...v, updatedDate: e.target.value })} /></Label>
      </div>
      <Label text="内容の要約"><Textarea className="min-h-28" placeholder="この資料で分かること、確認すべき点" value={v.summary} onChange={(e) => setV({ ...v, summary: e.target.value })} /></Label>
      <Label text="重要な数字"><Textarea className="min-h-24" placeholder="例：現在残高 3,200,000円／月返済 82,000円" value={v.keyNumbers} onChange={(e) => setV({ ...v, keyNumbers: e.target.value })} /></Label>
      <Label text="Google Driveリンク"><Input required type="url" inputMode="url" placeholder="https://drive.google.com/..." value={v.driveUrl} onChange={(e) => setV({ ...v, driveUrl: e.target.value })} /></Label>
      <div>
        <p className="text-sm font-bold">関連タスク（複数選択可）</p>
        <div className="mt-2 max-h-52 space-y-1 overflow-y-auto rounded-xl border bg-slate-50 p-2">
          {tasks.map((task) => (
            <label key={task.id} className="flex min-h-11 items-center gap-3 rounded-lg bg-white px-3 py-2 text-sm font-semibold">
              <input className="h-5 w-5" type="checkbox" checked={selected.has(task.id)} onChange={() => toggleTask(task.id)} />
              {task.name}
            </label>
          ))}
          {!tasks.length && <p className="p-3 text-sm text-slate-500">関連付けできる新棟タスクはありません</p>}
        </div>
      </div>
      <div className="sticky bottom-0 -mx-5 flex gap-2 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
        {onDelete && (
          <AlertDialog>
            <AlertDialogTrigger asChild><Button type="button" variant="outline" disabled={saving} className="h-12 border-red-200 text-red-600">削除</Button></AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader><AlertDialogTitle>この資料情報を削除しますか？</AlertDialogTitle><AlertDialogDescription>アプリ内の登録だけを削除します。Google Drive上の原本は削除されません。</AlertDialogDescription></AlertDialogHeader>
              <AlertDialogFooter><AlertDialogCancel>キャンセル</AlertDialogCancel><AlertDialogAction onClick={onDelete} className="bg-red-600 hover:bg-red-700">削除する</AlertDialogAction></AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
        <Button type="submit" disabled={saving} className="h-12 flex-1 bg-blue-600 text-base font-black shadow-lg">
          {saving && <Loader2 className="animate-spin" />}{saving ? "保存中…" : saveLabel}
        </Button>
      </div>
    </form>
  );
}

function BorrowingList({ rows, create, patch, remove }: {
  rows: Borrowing[];
  create: Props["create"];
  patch: Props["patch"];
  remove: Props["remove"];
}) {
  const balance = rows.reduce((sum, x) => sum + x.currentBalance, 0);
  const monthly = rows.reduce((sum, x) => sum + x.monthlyPayment, 0);
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <Metric icon={Landmark} label="借入件数" value={`${rows.length}件`} />
        <Metric icon={Banknote} label="現在残高 合計" value={yen(balance)} />
        <Metric icon={Banknote} label="月々返済額 合計" value={yen(monthly)} />
      </div>
      <div className="flex justify-end"><BorrowingDialog create={create} /></div>
      <div className="space-y-3 lg:hidden">
        {rows.map((row) => (
          <article key={row.id} className="rounded-2xl border bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3"><h3 className="text-lg font-black">{row.lender}</h3><EditBorrowing row={row} patch={patch} remove={remove} /></div>
            <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
              <Value label="当初借入額" value={yen(row.originalAmount)} />
              <Value label="現在残高" value={yen(row.currentBalance)} accent />
              <Value label="月々の元金" value={yen(row.monthlyPrincipal)} />
              <Value label="利息込み返済額" value={yen(row.monthlyPayment)} />
              <Value label="金利" value={`${row.interestRate}%`} />
              <Value label="完済予定日" value={fmtDate(row.maturityDate)} />
            </div>
            <ScheduleLink url={row.scheduleUrl} />
          </article>
        ))}
      </div>
      <div className="hidden overflow-x-auto rounded-2xl border bg-white lg:block">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-600">
            <tr>{["借入先","当初借入額","現在残高","月々の元金","利息込み返済額","金利","完済予定日","返済予定表",""].map((x) => <th key={x} className="whitespace-nowrap px-4 py-3">{x}</th>)}</tr>
          </thead>
          <tbody className="divide-y">
            {rows.map((row) => (
              <tr key={row.id}>
                <td className="px-4 py-3 font-black">{row.lender}</td>
                <td className="whitespace-nowrap px-4 py-3">{yen(row.originalAmount)}</td>
                <td className="whitespace-nowrap px-4 py-3 font-black text-blue-700">{yen(row.currentBalance)}</td>
                <td className="whitespace-nowrap px-4 py-3">{yen(row.monthlyPrincipal)}</td>
                <td className="whitespace-nowrap px-4 py-3">{yen(row.monthlyPayment)}</td>
                <td className="whitespace-nowrap px-4 py-3">{row.interestRate}%</td>
                <td className="whitespace-nowrap px-4 py-3">{fmtDate(row.maturityDate)}</td>
                <td className="px-4 py-3"><ScheduleLink url={row.scheduleUrl} compact /></td>
                <td className="px-4 py-3"><EditBorrowing row={row} patch={patch} remove={remove} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!rows.length && <div className="rounded-2xl border border-dashed bg-white py-14 text-center font-bold text-slate-500">借入金を登録すると、残高と月々の返済額をまとめて確認できます</div>}
    </div>
  );
}

function freshBorrowing() {
  return { lender: "", originalAmount: 0, currentBalance: 0, monthlyPrincipal: 0, monthlyPayment: 0, interestRate: 0, maturityDate: "", scheduleUrl: "", memo: "" };
}

function BorrowingDialog({ create }: { create: Props["create"] }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [v, setV] = useState(freshBorrowing);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (await create("borrowings", v)) {
        setV(freshBorrowing());
        setOpen(false);
      }
    } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => !saving && setOpen(next)}>
      <DialogTrigger asChild><Button className="h-11 bg-blue-600 font-black"><Plus />借入金を追加</Button></DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-2xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle>借入金を追加</DialogTitle></DialogHeader>
        <BorrowingForm v={v} setV={setV} submit={submit} saving={saving} saveLabel="借入金を保存" />
      </DialogContent>
    </Dialog>
  );
}

function EditBorrowing({ row, patch, remove }: { row: Borrowing; patch: Props["patch"]; remove: Props["remove"] }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [v, setV] = useState({ ...row });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try { if (await patch("borrowings", row.id, v)) setOpen(false); }
    finally { setSaving(false); }
  };
  const del = async () => {
    setSaving(true);
    try { if (await remove("borrowings", row.id)) setOpen(false); }
    finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => { if (saving) return; if (next) setV({ ...row }); setOpen(next); }}>
      <DialogTrigger asChild><Button variant="outline" size="sm" className="font-bold"><Pencil size={15} />編集</Button></DialogTrigger>
      <DialogContent className="max-h-[94dvh] overflow-hidden p-0 sm:max-w-2xl">
        <DialogHeader className="border-b px-5 py-4"><DialogTitle>借入金を編集</DialogTitle></DialogHeader>
        <BorrowingForm v={v} setV={setV} submit={submit} saving={saving} saveLabel="変更を保存" onDelete={del} />
      </DialogContent>
    </Dialog>
  );
}

function BorrowingForm({ v, setV, submit, saving, saveLabel, onDelete }: {
  v: Omit<Borrowing, "id"> | Borrowing;
  setV: (value: any) => void;
  submit: (e: React.FormEvent) => void;
  saving: boolean;
  saveLabel: string;
  onDelete?: () => void;
}) {
  const numberField = (key: keyof Borrowing, value: string) => setV({ ...v, [key]: Number(value) || 0 });
  return (
    <form onSubmit={submit} className="max-h-[calc(94dvh-4.5rem)] space-y-4 overflow-y-auto px-5 pb-3">
      <Label text="借入先"><Input required value={v.lender} onChange={(e) => setV({ ...v, lender: e.target.value })} /></Label>
      <div className="grid gap-3 sm:grid-cols-2">
        <Label text="当初借入額"><Input required type="number" min="0" value={v.originalAmount} onChange={(e) => numberField("originalAmount", e.target.value)} /></Label>
        <Label text="現在残高"><Input required type="number" min="0" value={v.currentBalance} onChange={(e) => numberField("currentBalance", e.target.value)} /></Label>
        <Label text="月々の元金返済額"><Input required type="number" min="0" value={v.monthlyPrincipal} onChange={(e) => numberField("monthlyPrincipal", e.target.value)} /></Label>
        <Label text="利息を含む返済額"><Input required type="number" min="0" value={v.monthlyPayment} onChange={(e) => numberField("monthlyPayment", e.target.value)} /></Label>
        <Label text="金利（%）"><Input required type="number" min="0" step="0.001" value={v.interestRate} onChange={(e) => numberField("interestRate", e.target.value)} /></Label>
        <Label text="完済予定日"><Input type="date" value={v.maturityDate} onChange={(e) => setV({ ...v, maturityDate: e.target.value })} /></Label>
      </div>
      <Label text="返済予定表へのリンク"><Input type="url" inputMode="url" placeholder="https://drive.google.com/..." value={v.scheduleUrl} onChange={(e) => setV({ ...v, scheduleUrl: e.target.value })} /></Label>
      <Label text="メモ"><Textarea value={v.memo} onChange={(e) => setV({ ...v, memo: e.target.value })} /></Label>
      <div className="sticky bottom-0 -mx-5 flex gap-2 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
        {onDelete && (
          <AlertDialog>
            <AlertDialogTrigger asChild><Button type="button" variant="outline" disabled={saving} className="h-12 border-red-200 text-red-600">削除</Button></AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader><AlertDialogTitle>この借入金情報を削除しますか？</AlertDialogTitle><AlertDialogDescription>一覧から削除され、元に戻せません。</AlertDialogDescription></AlertDialogHeader>
              <AlertDialogFooter><AlertDialogCancel>キャンセル</AlertDialogCancel><AlertDialogAction onClick={onDelete} className="bg-red-600 hover:bg-red-700">削除する</AlertDialogAction></AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
        <Button type="submit" disabled={saving} className="h-12 flex-1 bg-blue-600 text-base font-black shadow-lg">
          {saving && <Loader2 className="animate-spin" />}{saving ? "保存中…" : saveLabel}
        </Button>
      </div>
    </form>
  );
}

function ScheduleLink({ url, compact = false }: { url: string; compact?: boolean }) {
  const href = safeUrl(url);
  if (!href) return <span className={compact ? "text-slate-400" : "mt-3 block text-sm text-slate-400"}>リンク未設定</span>;
  return (
    <a href={href} target="_blank" rel="noreferrer" className={`${compact ? "" : "mt-3 "}inline-flex items-center gap-1 font-bold text-blue-700 hover:underline`}>
      <ExternalLink size={16} />返済予定表
    </a>
  );
}

function Metric({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return <div className="rounded-2xl border bg-white p-4 shadow-sm"><Icon className="text-blue-600" size={21} /><p className="mt-3 text-2xl font-black">{value}</p><p className="text-sm font-semibold text-slate-500">{label}</p></div>;
}

function Value({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return <div><p className="text-xs font-bold text-slate-500">{label}</p><p className={`mt-1 font-black ${accent ? "text-blue-700" : ""}`}>{value}</p></div>;
}

function Label({ text, children }: { text: string; children: React.ReactNode }) {
  return <label className="block text-sm font-bold">{text}<div className="mt-1">{children}</div></label>;
}

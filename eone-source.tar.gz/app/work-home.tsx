"use client";

import {
  ArrowRight,
  Building2,
  CalendarDays,
  ClipboardList,
  NotebookTabs,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

type Task = {
  id: number;
  name: string;
  scope: string;
  dueDate: string;
  priority: string;
  status: string;
  nextAction: string;
};
type CaseMemo = {
  id: number;
  personName: string;
  date: string;
  title: string;
  taskId: number | null;
};
type Props = { tasks: Task[]; cases: CaseMemo[]; go: (view: string) => void };

const today = new Intl.DateTimeFormat("sv-SE", {
  timeZone: "Asia/Tokyo",
}).format(new Date());
const fmt = (s: string) => (s ? `${+s.slice(5, 7)}/${+s.slice(8, 10)}` : "—");
const active = (t: Task) => t.status !== "完了" && t.status !== "保留";

export function WorkHome({ tasks, cases, go }: Props) {
  const open = tasks.filter(active);
  const late = open.filter((t) => !!t.dueDate && t.dueDate < today);
  const waiting = tasks.filter((t) => t.status === "確認待ち");
  const project = tasks.filter((t) => t.scope === "新棟オープン");
  const caseTasks = tasks.filter((t) => t.scope === "ケース対応");
  const projectDone = project.filter((t) => t.status === "完了").length;
  const projectProgress = project.length
    ? Math.round((projectDone / project.length) * 100)
    : 0;
  const nextProject = [...project].filter(active).sort(taskOrder)[0];
  const nextCase = [...caseTasks].filter(active).sort(taskOrder)[0];
  const next = [...open].sort(taskOrder).slice(0, 6);
  const caseActive = caseTasks.filter(active).length;
  return (
    <div className="space-y-6">
      <section className="rounded-[26px] bg-gradient-to-br from-[#203d68] via-[#315f9f] to-[#5689cf] p-6 text-white shadow-lg sm:p-8">
        <div className="grid gap-6 lg:grid-cols-[1.15fr_.85fr] lg:items-end">
          <div>
            <p className="font-bold text-blue-100">仕事の全体像</p>
            <h2 className="mt-1 text-3xl font-black sm:text-4xl">
              今日、何からする？
            </h2>
            <p className="mt-3 max-w-xl text-blue-50">
              新棟の準備も、利用者さんの対応も、ここで優先順位を確認できます。
            </p>
          </div>
          <div className="grid grid-cols-3 gap-2 rounded-2xl bg-white/12 p-3 backdrop-blur-sm">
            <HeroMetric
              label="今日まで"
              value={`${open.filter((t) => !!t.dueDate && t.dueDate <= today).length}件`}
            />
            <HeroMetric
              label="期限超過"
              value={`${late.length}件`}
              alert={late.length > 0}
            />
            <HeroMetric label="確認待ち" value={`${waiting.length}件`} />
          </div>
        </div>
      </section>

      <div className="grid gap-5 xl:grid-cols-2">
        <Gateway
          tone="blue"
          icon={Building2}
          title="新棟オープン"
          description="2027年8月1日のOPENに向けた準備"
          action="新棟オープンを開く"
          onClick={() => go("dashboard")}
        >
          <div className="rounded-xl bg-white/80 p-4">
            <div className="flex items-center justify-between">
              <b>準備の進捗</b>
              <b className="text-xl">{projectProgress}%</b>
            </div>
            <Progress value={projectProgress} className="mt-2 h-2.5" />
            <p className="mt-2 text-sm text-slate-600">
              完了 {projectDone}件 ／ 全{project.length}件
            </p>
          </div>
          <Next label="次にすること" task={nextProject} />
        </Gateway>
        <Gateway
          tone="rose"
          icon={NotebookTabs}
          title="ケース対応"
          description="既存ホームの利用者さんに関する記録と対応"
          action="ケース対応を開く"
          onClick={() => go("cases")}
        >
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-white/80 p-4">
              <p className="text-sm font-bold text-slate-500">ケース案件</p>
              <b className="text-2xl">{cases.length}件</b>
            </div>
            <div className="rounded-xl bg-white/80 p-4">
              <p className="text-sm font-bold text-slate-500">対応中</p>
              <b className="text-2xl">{caseActive}件</b>
            </div>
          </div>
          <Next label="次のケース対応" task={nextCase} />
        </Gateway>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-slate-500">
                新棟＋ケース対応
              </p>
              <h2 className="text-xl font-black">期限の近い仕事</h2>
            </div>
            <Button variant="outline" onClick={() => go("focus")}>
              今日・今週を見る
            </Button>
          </div>
          <div className="divide-y">
            {next.map((t) => (
              <button
                key={t.id}
                onClick={() => go("tasks")}
                className="grid w-full gap-2 py-3 text-left sm:grid-cols-[auto_1fr_auto] sm:items-center"
              >
                <Area scope={t.scope} />
                <div>
                  <b>{t.name}</b>
                  <p className="mt-0.5 text-sm text-slate-500">
                    {t.nextAction || "次の行動は未設定"}
                  </p>
                </div>
                <span
                  className={`text-sm font-black ${t.dueDate && t.dueDate < today ? "text-red-600" : "text-slate-600"}`}
                >
                  {t.dueDate ? `${fmt(t.dueDate)}まで` : "期限未設定"}
                </span>
              </button>
            ))}
            {!next.length && (
              <p className="py-8 text-center font-bold text-slate-400">
                対応中のタスクはありません
              </p>
            )}
          </div>
        </section>
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-xl font-black">すぐ記録する</h2>
          <p className="mt-1 text-sm text-slate-500">
            思い出したときに、ここから移動できます。
          </p>
          <div className="mt-5 space-y-3">
            <Button
              className="h-12 w-full justify-between bg-blue-600 text-base font-black"
              onClick={() => go("tasks")}
            >
              <span className="flex items-center gap-2">
                <ClipboardList />
                全タスクへ
              </span>
              <ArrowRight />
            </Button>
            <Button
              className="h-12 w-full justify-between bg-[#c45572] text-base font-black hover:bg-[#ad4762]"
              onClick={() => go("cases")}
            >
              <span className="flex items-center gap-2">
                <NotebookTabs />
                ケース案件へ
              </span>
              <ArrowRight />
            </Button>
          </div>
          <div className="mt-5 rounded-xl bg-slate-50 p-4">
            <div className="flex items-center gap-2 text-sm font-black text-slate-600">
              <CalendarDays size={18} />
              管理の分け方
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              銀行・行政・建物は「新棟」。利用者さんの申請やモニタリングは「ケース対応」に入ります。
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}

function taskOrder(a: Task, b: Task) {
  const p: Record<string, number> = { 最優先: 4, 高: 3, 中: 2, 低: 1 };
  return (
    (a.dueDate || "9999-12-31").localeCompare(b.dueDate || "9999-12-31") ||
    (p[b.priority] || 0) - (p[a.priority] || 0)
  );
}
function HeroMetric({
  label,
  value,
  alert = false,
}: {
  label: string;
  value: string;
  alert?: boolean;
}) {
  return (
    <div className="text-center">
      <p className="text-xs font-bold text-blue-100">{label}</p>
      <b
        className={`mt-1 block text-xl sm:text-2xl ${alert ? "text-amber-200" : ""}`}
      >
        {value}
      </b>
    </div>
  );
}
function Area({ scope }: { scope: string }) {
  return (
    <span
      className={`w-fit rounded-full px-2.5 py-1 text-xs font-black ${scope === "ケース対応" ? "bg-rose-50 text-rose-700" : "bg-blue-50 text-blue-700"}`}
    >
      {scope === "ケース対応" ? "ケース" : "新棟"}
    </span>
  );
}
function Next({ label, task }: { label: string; task?: Task }) {
  return (
    <div className="mt-3 rounded-xl border border-white/70 bg-white/65 p-4">
      <p className="text-xs font-black text-slate-500">{label}</p>
      {task ? (
        <>
          <b className="mt-1 block">{task.name}</b>
          <p className="mt-1 text-sm text-slate-600">
            {task.nextAction || "次の行動は未設定"} ・{" "}
            {task.dueDate ? `${fmt(task.dueDate)}まで` : "期限未設定"}
          </p>
        </>
      ) : (
        <p className="mt-1 text-sm text-slate-500">
          対応中のタスクはありません
        </p>
      )}
    </div>
  );
}
function Gateway({
  tone,
  icon: Icon,
  title,
  description,
  action,
  onClick,
  children,
}: {
  tone: "blue" | "rose";
  icon: any;
  title: string;
  description: string;
  action: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  const rose = tone === "rose";
  return (
    <section
      className={`rounded-[24px] border p-5 shadow-sm sm:p-6 ${rose ? "border-rose-200 bg-gradient-to-br from-rose-50 to-white" : "border-blue-200 bg-gradient-to-br from-blue-50 to-white"}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span
            className={`grid h-12 w-12 place-items-center rounded-2xl text-white ${rose ? "bg-[#c45572]" : "bg-blue-600"}`}
          >
            <Icon />
          </span>
          <div>
            <h2 className="text-xl font-black">{title}</h2>
            <p className="text-sm text-slate-600">{description}</p>
          </div>
        </div>
      </div>
      <div className="mt-5">{children}</div>
      <Button
        onClick={onClick}
        className={`mt-4 h-11 w-full justify-between font-black ${rose ? "bg-[#c45572] hover:bg-[#ad4762]" : "bg-blue-600"}`}
      >
        {action}
        <ArrowRight />
      </Button>
    </section>
  );
}

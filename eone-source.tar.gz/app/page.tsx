"use client";
import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Banknote,
  Building2,
  CalendarClock,
  CalendarDays,
  ChevronRight,
  ClipboardList,
  Clock3,
  ContactRound,
  FolderOpen,
  Home,
  Menu,
  NotebookTabs,
  Loader2,
  Plus,
  RefreshCw,
  Search,
  Users,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { toast, Toaster } from "sonner";
import { dataRequest } from "@/lib/data-request";
import { importSeed, loadData } from "@/lib/firestore-data";
import {
  allowedEmail,
  auth,
  loginWithGoogle,
  logout,
} from "@/lib/firebase";
import { onAuthStateChanged, type User } from "firebase/auth";
import { contactMethods } from "@/lib/mutation-validation";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Cases } from "./cases";
import { WorkHome } from "./work-home";
import {
  Documents,
  linkedTaskIds,
  type Borrowing,
  type ProjectDocument,
} from "./documents";
type Task = {
  id: number;
  name: string;
  category: string;
  scope: string;
  dueDate: string;
  assignee: string;
  priority: string;
  status: string;
  memo: string;
  nextAction: string;
  contact: string;
  resourceUrl: string;
  startMonth: string;
  endMonth: string;
};
type Candidate = {
  id: number;
  alias: string;
  supportLevel: string;
  daytimePlace: string;
  supportOffice: string;
  consultant: string;
  interest: string;
  familyIntent: string;
  tourStatus: string;
  trialStatus: string;
  expectedMoveIn: string;
  nextContactDate: string;
  memo: string;
};
type Fund = {
  id: number;
  item: string;
  estimated: number;
  confirmed: number;
  paid: number;
  memo: string;
};
type Loan = {
  id: number;
  lender: string;
  requested: number;
  consultationDate: string;
  response: string;
  memo: string;
};
type Contact = {
  id: number;
  date: string;
  organization: string;
  person: string;
  method: string;
  content: string;
  response: string;
  nextDate: string;
  waiting: boolean;
};
type CaseMemo = {
  id: number;
  personName: string;
  date: string;
  title: string;
  content: string;
  nextAction: string;
  dueDate: string;
  priority: string;
  stage: string;
  taskId: number | null;
};
type CaseUpdate = {
  id: number;
  caseId: number;
  date: string;
  stage: string;
  content: string;
  nextAction: string;
  dueDate: string;
};
type Data = {
  tasks: Task[];
  candidates: Candidate[];
  funds: Fund[];
  loans: Loan[];
  contacts: Contact[];
  cases: CaseMemo[];
  caseUpdates: CaseUpdate[];
  projectDocuments: ProjectDocument[];
  borrowings: Borrowing[];
};
const projectCategories = [
    "行政・指定",
    "利用者募集",
    "人材・勤務体制",
    "資金・融資",
    "建物・消防・備品",
  ],
  categories = [...projectCategories, "利用者対応"],
  statuses = ["未着手", "進行中", "確認待ち", "完了", "保留"],
  interests = ["情報提供のみ", "興味あり", "検討中", "有力", "入居予定"];
const colors: Record<string, string> = {
  "行政・指定": "#4d78cc",
  利用者募集: "#e88846",
  利用者対応: "#d86b84",
  "人材・勤務体制": "#8c68c5",
  "資金・融資": "#2b9a86",
  "建物・消防・備品": "#d2a52c",
};
const nav = [
  { id: "home", label: "仕事ホーム", icon: Home, group: "全体" },
  { id: "focus", label: "今日・今週", icon: Clock3, group: "全体" },
  { id: "tasks", label: "全タスク", icon: ClipboardList, group: "全体" },
  {
    id: "dashboard",
    label: "新棟ダッシュボード",
    icon: Building2,
    group: "新棟オープン",
  },
  {
    id: "roadmap",
    label: "ロードマップ",
    icon: CalendarDays,
    group: "新棟オープン",
  },
  { id: "candidates", label: "入居候補者", icon: Users, group: "新棟オープン" },
  { id: "funds", label: "資金・融資", icon: Banknote, group: "新棟オープン" },
  {
    id: "contacts",
    label: "連絡履歴",
    icon: ContactRound,
    group: "新棟オープン",
  },
  {
    id: "documents",
    label: "資料・データ",
    icon: FolderOpen,
    group: "新棟オープン",
  },
  { id: "cases", label: "ケース案件", icon: NotebookTabs, group: "ケース対応" },
];
const today = new Intl.DateTimeFormat("sv-SE", {
  timeZone: "Asia/Tokyo",
}).format(new Date());
const day = (s: string, n: number) => {
  const d = new Date(`${s}T00:00:00+09:00`);
  d.setDate(d.getDate() + n);
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Tokyo" }).format(d);
};
const weekEnd = day(today, 6);
const yen = (n: number) =>
  new Intl.NumberFormat("ja-JP", {
    style: "currency",
    currency: "JPY",
    maximumFractionDigits: 0,
  }).format(n);
const fmt = (s: string) => (s ? `${+s.slice(5, 7)}/${+s.slice(8, 10)}` : "—");
const dueKey = (s: string) => s || "9999-12-31";
export default function Page() {
  const [view, setView] = useState("home"),
    [data, setData] = useState<Data | null>(null),
    [loading, setLoading] = useState(true),
    [loadError, setLoadError] = useState(""),
    [menu, setMenu] = useState(false),
    [documentFocus, setDocumentFocus] = useState<number | null>(null),
    [user, setUser] = useState<User | null>(null),
    [authReady, setAuthReady] = useState(false),
    [authError, setAuthError] = useState(""),
    [loggingIn, setLoggingIn] = useState(false),
    [importMode, setImportMode] = useState(false);
  const load = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    setLoadError("");
    try {
      setData((await loadData()) as Data);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : "データを読み込めませんでした。");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    setImportMode(new URLSearchParams(window.location.search).get("import") === "1");
    return onAuthStateChanged(auth, async (nextUser) => {
      if (nextUser && nextUser.email !== allowedEmail) {
        await logout();
        setUser(null);
        setAuthError("このGoogleアカウントにはアクセス権がありません。");
      } else {
        setUser(nextUser);
      }
      setAuthReady(true);
      if (!nextUser) setLoading(false);
    });
  }, []);
  useEffect(() => {
    if (user) load();
  }, [user]);
  const login = async () => {
    setLoggingIn(true);
    setAuthError("");
    try {
      await loginWithGoogle();
    } catch (error) {
      setAuthError(
        error instanceof Error ? error.message : "Googleログインに失敗しました。",
      );
    } finally {
      setLoggingIn(false);
    }
  };
  const openDocument = (id: number) => {
    setDocumentFocus(id);
    setView("documents");
  };
  const mutate = async (method: string, body: unknown) => {
    try {
      return await dataRequest(method, body);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "保存できませんでした。");
      return null;
    }
  };
  const patch = async (
    table: string,
    id: number,
    values: Record<string, unknown>,
  ) => {
    const j = await mutate("PATCH", { table, id, data: values });
    if (j) {
      setData((d) =>
        d
          ? ({
              ...d,
              [table]: (d[table as keyof Data] as { id: number }[]).map((x) =>
                x.id === id ? (j.row ?? { ...x, ...values }) : x,
              ),
              ...(j.task
                ? {
                    tasks: d.tasks.map((task) =>
                      task.id === j.task.id ? j.task : task,
                    ),
                  }
                : {}),
              ...(j.case
                ? {
                    cases: d.cases.map((item) =>
                      item.id === j.case.id ? j.case : item,
                    ),
                  }
                : {}),
            } as Data)
          : d,
      );
      toast.success("更新しました");
      return true;
    }
    return false;
  };
  const remove = async (table: string, id: number) => {
    const j = await mutate("DELETE", { table, id });
    if (j) {
      setData((d) =>
        d
          ? ({
              ...d,
              [table]: (d[table as keyof Data] as { id: number }[]).filter(
                (x) => x.id !== id,
              ),
              ...(j.deletedTaskId
                ? {
                    tasks: d.tasks.filter(
                      (task) => task.id !== j.deletedTaskId,
                    ),
                  }
                : {}),
            } as Data)
          : d,
      );
      toast.success("削除しました");
      return true;
    }
    return false;
  };
  const create = async (table: string, values: Record<string, unknown>) => {
    const j = await mutate("POST", { table, data: values });
    if (j) {
      setData((d) =>
        d
          ? ({
              ...d,
              [table]: [...(d[table as keyof Data] as unknown[]), j.row],
              ...(j.task
                ? {
                    tasks: d.tasks.some((task) => task.id === j.task.id)
                      ? d.tasks.map((task) =>
                          task.id === j.task.id ? j.task : task,
                        )
                      : [...d.tasks, j.task],
                  }
                : {}),
              ...(j.case
                ? {
                    cases: d.cases.map((item) =>
                      item.id === j.case.id ? j.case : item,
                    ),
                  }
                : {}),
            } as Data)
          : d,
      );
      toast.success(
        table === "caseUpdates"
          ? "経過と次の対応を更新しました"
          : j.task
            ? "案件とタスクを登録しました"
            : "登録しました",
      );
      return true;
    }
    return false;
  };
  if (!authReady)
    return (
      <div className="min-h-screen grid place-items-center bg-[#f5f8fc]">
        <div className="text-center">
          <RefreshCw className="mx-auto mb-3 animate-spin text-blue-600" />
          <p>安全な接続を確認しています</p>
        </div>
      </div>
    );
  if (!user)
    return (
      <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-[#edf5ff] via-white to-[#fef4df] p-5">
        <div className="w-full max-w-md rounded-[28px] border border-white bg-white/95 p-7 text-center shadow-xl sm:p-9">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-blue-600 text-white shadow-lg">
            <Building2 size={34} />
          </div>
          <p className="mt-6 text-sm font-black text-blue-600">
            山手 新棟オープンプロジェクト
          </p>
          <h1 className="mt-2 text-3xl font-black">仕事管理</h1>
          <p className="mt-4 leading-7 text-slate-600">
            タスク・連絡履歴・資金・資料を、どの端末からでも同じ内容で確認できます。
          </p>
          {authError && (
            <div role="alert" className="mt-5 rounded-xl bg-red-50 p-3 text-sm font-bold text-red-700">
              {authError}
            </div>
          )}
          <Button
            className="mt-7 h-12 w-full bg-blue-600 text-base font-black"
            onClick={login}
            disabled={loggingIn}
          >
            {loggingIn ? <Loader2 className="animate-spin" /> : null}
            Googleアカウントでログイン
          </Button>
          <p className="mt-4 text-xs text-slate-500">
            登録済みのGoogleアカウントだけが利用できます。
          </p>
        </div>
      </main>
    );
  if (importMode)
    return (
      <SeedImporter
        onDone={async () => {
          window.history.replaceState({}, "", window.location.pathname);
          setImportMode(false);
          await load();
        }}
      />
    );
  if (!loading && !data)
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
        <div role="alert" className="max-w-md space-y-4 rounded-2xl border bg-white p-6 text-center">
          <h1 className="text-xl font-bold">データを読み込めませんでした</h1>
          <p>{loadError || "通信状況を確認して、もう一度お試しください。"}</p>
          <Button onClick={load}>再読み込み</Button>
        </div>
      </main>
    );
  if (loading || !data)
    return (
      <div className="min-h-screen grid place-items-center bg-[#f5f8fc]">
        <div className="text-center">
          <RefreshCw className="mx-auto mb-3 animate-spin text-blue-600" />
          <p>仕事のデータを読み込んでいます</p>
        </div>
      </div>
    );
  return (
    <div className="min-h-screen bg-[#f5f8fc] text-[#20304a]">
      <Toaster richColors position="top-center" />
      <header className="sticky top-0 z-30 flex h-16 items-center border-b bg-white px-4 lg:hidden">
        <button onClick={() => setMenu(true)}>
          <Menu />
        </button>
        <b className="ml-3">
          イーワンスクエア　
          <span className="text-sm text-slate-500">仕事管理</span>
        </b>
        <Button variant="ghost" size="sm" className="ml-auto" onClick={() => logout()}>
          ログアウト
        </Button>
      </header>
      {menu && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/40 lg:hidden"
          onClick={() => setMenu(false)}
        >
          <aside
            className="h-full w-[290px] overflow-y-auto bg-white p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <button className="float-right" onClick={() => setMenu(false)}>
              <X />
            </button>
            <Side
              view={view}
              setView={(x) => {
                setView(x);
                setMenu(false);
              }}
            />
          </aside>
        </div>
      )}
      <aside className="fixed inset-y-0 left-0 hidden w-[270px] overflow-y-auto border-r bg-white p-4 pt-7 lg:block">
        <Side view={view} setView={setView} />
      </aside>
      <main className="mx-auto max-w-[1540px] px-4 py-6 lg:ml-[270px] lg:px-8">
        {loadError && (
          <div role="alert" className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-4">
            最新データを取得できませんでした。表示中の内容は前回取得したものです。
            <Button variant="outline" className="ml-3" onClick={load}>再読み込み</Button>
          </div>
        )}
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm font-bold text-blue-600">
              {view === "cases"
                ? "既存ホーム・利用者対応"
                : [
                      "dashboard",
                      "roadmap",
                      "candidates",
                      "funds",
                      "contacts",
                      "documents",
                    ].includes(view)
                  ? "山手 新棟オープンプロジェクト"
                  : "イーワンスクエア 仕事管理"}
            </p>
            <h1 className="text-3xl font-black">
              {nav.find((n) => n.id === view)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {["dashboard", "roadmap", "candidates", "funds", "contacts", "documents"].includes(
              view,
            ) && (
              <p className="rounded-full bg-white px-4 py-2 text-sm shadow-sm">
                開設予定 <b>2027年8月1日</b>
              </p>
            )}
            <Button variant="outline" size="sm" className="hidden lg:inline-flex" onClick={() => logout()}>
              ログアウト
            </Button>
          </div>
        </div>
        {view === "home" && (
          <WorkHome tasks={data.tasks} cases={data.cases} go={setView} />
        )}{" "}
        {view === "dashboard" && <Dashboard data={data} go={setView} />}{" "}
        {view === "focus" && <Focus tasks={data.tasks} patch={patch} />}{" "}
        {view === "tasks" && (
          <Tasks
            tasks={data.tasks}
            documents={data.projectDocuments}
            openDocument={openDocument}
            patch={patch}
            create={create}
          />
        )}{" "}
        {view === "cases" && (
          <Cases
            rows={data.cases}
            updates={data.caseUpdates}
            tasks={data.tasks}
            create={create}
            patch={patch}
            remove={remove}
          />
        )}{" "}
        {view === "roadmap" && (
          <Roadmap
            tasks={data.tasks.filter((t) => t.scope === "新棟オープン")}
          />
        )}{" "}
        {view === "candidates" && (
          <Candidates rows={data.candidates} patch={patch} create={create} />
        )}{" "}
        {view === "funds" && (
          <Funds
            funds={data.funds}
            loans={data.loans}
            patch={patch}
            create={create}
          />
        )}{" "}
        {view === "contacts" && (
          <Contacts
            rows={data.contacts}
            patch={patch}
            create={create}
            remove={remove}
          />
        )}
        {view === "documents" && (
          <Documents
            documents={data.projectDocuments}
            borrowings={data.borrowings}
            tasks={data.tasks}
            focusId={documentFocus}
            create={create}
            patch={patch}
            remove={remove}
          />
        )}
      </main>
    </div>
  );
}

function SeedImporter({ onDone }: { onDone: () => Promise<void> }) {
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const run = async () => {
    setBusy(true);
    setMessage("");
    try {
      const seed = JSON.parse(value) as Record<string, Record<string, any>[]>;
      const count = await importSeed(seed as any);
      setMessage(`${count}件をFirebaseへ移行しました。`);
      await onDone();
    } catch (error) {
      setMessage(
        error instanceof Error ? error.message : "初期データを移行できませんでした。",
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <main className="min-h-screen bg-[#f5f8fc] p-5 sm:p-8">
      <section className="mx-auto max-w-3xl rounded-3xl border bg-white p-6 shadow-lg">
        <p className="text-sm font-black text-blue-600">管理者専用</p>
        <h1 className="mt-1 text-2xl font-black">初期データ移行</h1>
        <p className="mt-2 text-slate-600">
          旧アプリから取得したJSONをFirebaseへ移します。
        </p>
        <Textarea
          aria-label="移行データ"
          className="mt-5 min-h-[360px] font-mono text-xs"
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder="JSONを貼り付け"
        />
        {message && <p className="mt-3 font-bold">{message}</p>}
        <Button
          className="mt-5 h-12 w-full bg-blue-600 text-base font-black"
          disabled={busy || !value.trim()}
          onClick={run}
        >
          {busy ? <Loader2 className="animate-spin" /> : null}
          Firebaseへ移行
        </Button>
      </section>
    </main>
  );
}
function Side({
  view,
  setView,
}: {
  view: string;
  setView: (s: string) => void;
}) {
  return (
    <>
      <div className="mb-9 flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-blue-600 text-white">
          <Building2 />
        </span>
        <div>
          <b>イーワンスクエア</b>
          <p className="text-xs text-slate-500">仕事管理</p>
        </div>
      </div>
      <nav>
        {nav.map((n, i) => (
          <div key={n.id}>
            {(i === 0 || nav[i - 1].group !== n.group) && (
              <p
                className={`${i ? "mt-5" : ""} mb-1 px-3 text-xs font-black tracking-wide text-slate-400`}
              >
                {n.group}
              </p>
            )}
            <button
              onClick={() => setView(n.id)}
              className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left font-semibold ${view === n.id ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-50"}`}
            >
              <n.icon size={19} />
              {n.label}
            </button>
          </div>
        ))}
      </nav>
      <div className="mt-6 rounded-2xl bg-emerald-50 p-4">
        <p className="text-xs font-bold text-emerald-700">目標</p>
        <b className="text-sm">
          2027年春までに
          <br />
          入居候補者4名を確保
        </b>
      </div>
    </>
  );
}
function Card({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h2 className="mb-4 text-lg font-black">{title}</h2>
      {children}
    </section>
  );
}
function Dashboard({ data, go }: { data: Data; go: (s: string) => void }) {
  const [selected, setSelected] = useState<Task | null>(null);
  const t = data.tasks.filter((task) => task.scope === "新棟オープン"),
    done = t.filter((x) => x.status === "完了").length,
    p = Math.round((done / t.length) * 100),
    week = t.filter(
      (x) => x.status !== "完了" && x.dueDate >= today && x.dueDate <= weekEnd,
    ),
    late = t.filter(
      (x) => x.status !== "完了" && !!x.dueDate && x.dueDate < today,
    ),
    wait =
      t.filter((x) => x.status === "確認待ち").length +
      data.contacts.filter((x) => x.waiting).length,
    strong = data.candidates.filter((x) =>
      ["有力", "入居予定"].includes(x.interest),
    ).length,
    estimate = data.funds.reduce((a, b) => a + b.estimated, 0),
    borrow = data.loans.reduce((a, b) => a + b.requested, 0),
    hasEstimate = data.funds.some(
      (x) => x.estimated > 0 || x.confirmed > 0 || x.paid > 0,
    ),
    priority: Record<string, number> = { 最優先: 4, 高: 3, 中: 2, 低: 1 },
    next = [...t]
      .filter((x) => x.status !== "完了" && x.status !== "保留")
      .sort(
        (a, b) =>
          dueKey(a.dueDate).localeCompare(dueKey(b.dueDate)) ||
          (priority[b.priority] || 0) - (priority[a.priority] || 0),
      )[0];
  return (
    <div className="space-y-6">
      <section className="rounded-[24px] bg-gradient-to-br from-[#3567b1] to-[#5689cf] p-6 text-white shadow-lg sm:p-8">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <p className="font-bold text-blue-100">OPENまで</p>
            <p>
              <span className="text-6xl font-black">
                {Math.max(
                  0,
                  Math.ceil(
                    (new Date(2027, 7, 1).setHours(0, 0, 0, 0) -
                      new Date().setHours(0, 0, 0, 0)) /
                      86400000,
                  ),
                )}
              </span>{" "}
              <b className="text-xl">日</b>
            </p>
            <p className="mt-3 text-blue-100">
              完成時に、利用者・職員・手続き・資金がそろった状態へ
            </p>
          </div>
          <div className="self-end rounded-2xl bg-white/15 p-5">
            <div className="flex justify-between">
              <b>全体進捗</b>
              <b>{p}%</b>
            </div>
            <Progress value={p} className="mt-3 h-3 bg-white/25" />
            <p className="mt-3 text-sm">
              完了 {done}件 ／ 全{t.length}件
            </p>
          </div>
        </div>
      </section>
      {next && (
        <button
          onClick={() => setSelected(next)}
          className="group w-full rounded-2xl border-2 border-[#f0b64c] bg-gradient-to-r from-[#fff9e9] to-white p-5 text-left shadow-sm transition hover:shadow-md sm:p-6"
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-black text-[#a96c00]">次にやること</p>
              <h2 className="mt-1 text-xl font-black sm:text-2xl">
                {next.name}
              </h2>
              <p className="mt-2 text-sm text-slate-600">
                {next.nextAction || "次の行動を確認しましょう"}
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-sm">
                <span className="rounded-full bg-white px-3 py-1 font-bold text-red-600">
                  期限 {fmt(next.dueDate)}
                </span>
                <span className="rounded-full bg-white px-3 py-1 font-bold">
                  {next.priority}
                </span>
                <span className="rounded-full bg-white px-3 py-1">
                  {next.category}
                </span>
              </div>
            </div>
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#f0b64c] text-white transition group-hover:translate-x-0.5">
              <ChevronRight />
            </span>
          </div>
        </button>
      )}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>タスク詳細</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-bold text-blue-600">
                  {selected.category}
                </p>
                <h3 className="mt-1 text-xl font-black">{selected.name}</h3>
              </div>
              <div className="grid grid-cols-2 gap-3 rounded-xl bg-slate-50 p-4 text-sm">
                <p>
                  <span className="block text-slate-500">期限</span>
                  <b>{fmt(selected.dueDate)}</b>
                </p>
                <p>
                  <span className="block text-slate-500">優先度</span>
                  <b>{selected.priority}</b>
                </p>
                <p>
                  <span className="block text-slate-500">担当者</span>
                  <b>{selected.assignee}</b>
                </p>
                <p>
                  <span className="block text-slate-500">状態</span>
                  <b>{selected.status}</b>
                </p>
              </div>
              <div>
                <p className="text-sm font-bold text-slate-500">次にやること</p>
                <p className="mt-1 font-semibold">
                  {selected.nextAction || "未設定"}
                </p>
              </div>
              {selected.contact && (
                <div>
                  <p className="text-sm font-bold text-slate-500">連絡先</p>
                  <p className="mt-1">{selected.contact}</p>
                </div>
              )}
              {selected.memo && (
                <div>
                  <p className="text-sm font-bold text-slate-500">メモ</p>
                  <p className="mt-1">{selected.memo}</p>
                </div>
              )}
              <Button
                className="w-full"
                onClick={() => {
                  setSelected(null);
                  go("tasks");
                }}
              >
                全タスク画面で見る
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Metric
          l="今週やること"
          v={`${week.length}件`}
          I={CalendarDays}
          c="#4d78cc"
          go={() => go("focus")}
        />
        <Metric
          l="期限超過"
          v={`${late.length}件`}
          I={AlertCircle}
          c="#d85656"
          go={() => go("focus")}
        />
        <Metric
          l="確認待ち"
          v={`${wait}件`}
          I={Clock3}
          c="#d39b2c"
          go={() => go("focus")}
        />
        <Metric
          l="有力＋入居予定"
          v={`${strong}/4名`}
          I={Users}
          c="#e8783f"
          go={() => go("candidates")}
        />
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
        <Card title="カテゴリ別進捗">
          <div className="space-y-4">
            {projectCategories.map((c) => {
              const a = t.filter((x) => x.category === c),
                d = a.filter((x) => x.status === "完了").length,
                q = a.length ? Math.round((d / a.length) * 100) : 0;
              return (
                <div key={c}>
                  <div className="mb-1 flex justify-between text-sm">
                    <b>{c}</b>
                    <span>
                      {d}/{a.length}件　{q}%
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${q}%`, background: colors[c] }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
        <div className="grid gap-5">
          <Card title="職員確保状況">
            <p className="text-2xl font-black">計画作成前</p>
            <p className="text-sm text-slate-500">
              夜勤必要人数の算定が次の一手
            </p>
          </Card>
          <Card title="資金準備状況">
            <p className="text-sm text-slate-500">見込必要資金</p>
            <p className="text-3xl font-black">
              {hasEstimate ? yen(estimate) : "算定中"}
            </p>
            <p
              className={`mt-2 font-bold ${hasEstimate ? "text-red-600" : "text-slate-500"}`}
            >
              不足見込{" "}
              {hasEstimate ? yen(Math.max(0, estimate - borrow)) : "算定中"}
            </p>
          </Card>
        </div>
      </div>
      <Card title="直近の重要タスク">
        <Rows
          rows={t
            .filter((x) => x.status !== "完了")
            .sort((a, b) => dueKey(a.dueDate).localeCompare(dueKey(b.dueDate)))
            .slice(0, 5)}
        />
      </Card>
    </div>
  );
}
function Metric({
  l,
  v,
  I,
  c,
  go,
}: {
  l: string;
  v: string;
  I: any;
  c: string;
  go: () => void;
}) {
  return (
    <button
      onClick={go}
      className="rounded-2xl border bg-white p-4 text-left shadow-sm hover:shadow-md"
    >
      <div className="flex justify-between">
        <span
          className="grid h-10 w-10 place-items-center rounded-xl"
          style={{ background: c + "14", color: c }}
        >
          <I size={21} />
        </span>
        <ChevronRight className="text-slate-300" />
      </div>
      <p className="mt-4 text-3xl font-black">{v}</p>
      <p className="text-sm font-semibold text-slate-500">{l}</p>
    </button>
  );
}
function Status({ t, patch }: { t: Task; patch?: any }) {
  return (
    <span
      className={`rounded-full px-2 py-1 text-xs font-bold ${t.status === "完了" ? "bg-emerald-50 text-emerald-700" : t.status === "確認待ち" ? "bg-amber-50 text-amber-700" : t.status === "進行中" ? "bg-blue-50 text-blue-700" : "bg-slate-100 text-slate-600"}`}
    >
      <select
        className="bg-transparent"
        disabled={!patch}
        value={t.status}
        onChange={(e) => patch("tasks", t.id, { status: e.target.value })}
      >
        {statuses.map((s) => (
          <option key={s}>{s}</option>
        ))}
      </select>
    </span>
  );
}
function AreaBadge({ scope }: { scope: string }) {
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-xs font-black ${scope === "ケース対応" ? "bg-rose-50 text-rose-700" : "bg-blue-50 text-blue-700"}`}
    >
      {scope === "ケース対応" ? "ケース" : "新棟"}
    </span>
  );
}
function TaskDeadline({ t, patch }: { t: Task; patch?: any }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(t.dueDate);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const overdue = !!t.dueDate && t.dueDate < today && t.status !== "完了";
  if (!patch)
    return (
      <b className={overdue ? "text-red-600" : "text-slate-500"}>
        {t.dueDate ? `${fmt(t.dueDate)}まで` : "期限未設定"}
      </b>
    );
  const changeOpen = (next: boolean) => {
    if (saving) return;
    if (next) setValue(t.dueDate);
    setOpen(next);
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    try {
      if (await patch("tasks", t.id, { dueDate: value })) setOpen(false);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={changeOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className={`h-10 w-fit justify-start gap-2 font-black ${overdue ? "border-red-200 text-red-600" : t.dueDate ? "text-slate-600" : "border-amber-200 text-amber-700"}`}
        >
          <CalendarClock size={17} />
          {t.dueDate ? `${fmt(t.dueDate)}まで` : "期限を設定"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>期限を変更</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5">
          <div>
            <p className="mb-3 font-bold">{t.name}</p>
            <label className="block text-sm font-bold">
              期限
              <Input
                required
                className="mt-1 h-12"
                type="date"
                value={value}
                onChange={(e) => setValue(e.target.value)}
              />
            </label>
          </div>
          <Button
            type="submit"
            disabled={saving}
            className="h-12 w-full bg-blue-600 text-base font-black"
          >
            {saving && <Loader2 className="animate-spin" />}
            {saving ? "保存中…" : "期限を保存"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
function EditTask({ t, patch }: { t: Task; patch: any }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [v, setV] = useState({
    name: t.name,
    memo: t.memo,
    nextAction: t.nextAction,
    startMonth: t.startMonth,
    endMonth: t.endMonth,
  });
  useEffect(() => {
    if (open)
      setV({ name: t.name, memo: t.memo, nextAction: t.nextAction, startMonth: t.startMonth, endMonth: t.endMonth });
  }, [open, t]);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      const changes = Object.fromEntries(Object.entries(v).filter(([key, value]) => value !== t[key as keyof Task]));
      if (!Object.keys(changes).length || await patch("tasks", t.id, changes)) setOpen(false);
    } finally {
      setSaving(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => !saving && setOpen(next)}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-10 px-4 font-bold">
          編集
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[92dvh] overflow-hidden p-0 sm:max-w-lg">
        <DialogHeader className="border-b px-5 py-4">
          <DialogTitle>タスクを編集（ID {t.id}）</DialogTitle>
        </DialogHeader>
        <form
          onSubmit={submit}
          className="max-h-[calc(92dvh-4rem)] space-y-4 overflow-y-auto px-5 pb-2"
        >
          <label className="block text-sm font-bold">
            タスク名
            <Input
              required
              className="mt-1 h-12"
              value={v.name}
              onChange={(e) => setV({ ...v, name: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            次にやること
            <Textarea
              className="mt-1 min-h-24"
              value={v.nextAction || ""}
              onChange={(e) => setV({ ...v, nextAction: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            メモ
            <Textarea
              className="mt-1 min-h-48"
              value={v.memo || ""}
              onChange={(e) => setV({ ...v, memo: e.target.value })}
            />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="block text-sm font-bold">
              開始月
              <Input type="month" className="mt-1 h-12" value={v.startMonth} max={v.endMonth || undefined}
                onChange={(e) => setV({ ...v, startMonth: e.target.value })} />
            </label>
            <label className="block text-sm font-bold">
              終了月
              <Input type="month" className="mt-1 h-12" value={v.endMonth} min={v.startMonth || undefined}
                onChange={(e) => setV({ ...v, endMonth: e.target.value })} />
            </label>
          </div>
          <div className="sticky bottom-0 -mx-5 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
            <Button
              type="submit"
              disabled={saving}
              className="h-12 w-full bg-blue-600 text-base font-black shadow-lg"
            >
              {saving && <Loader2 className="animate-spin" />}
              {saving ? "保存中…" : "変更を保存"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
function Rows({
  rows,
  patch,
  documents = [],
  openDocument,
}: {
  rows: Task[];
  patch?: any;
  documents?: ProjectDocument[];
  openDocument?: (id: number) => void;
}) {
  return (
    <div className="divide-y">
      {rows.length ? (
        rows.map((t) => {
          const related = documents.filter((doc) =>
            linkedTaskIds(doc.relatedTaskIds).includes(t.id),
          );
          return (
            <div
              key={t.id}
              className="grid gap-2 py-3 sm:grid-cols-[1fr_auto_auto_auto] sm:items-center"
            >
              <div>
                <div className="flex items-center gap-2">
                  <i
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: colors[t.category] }}
                  />
                  <b>{t.name}</b>
                  <AreaBadge scope={t.scope} />
                </div>
                <p className="ml-4 mt-1 text-sm text-slate-500">
                  次：{t.nextAction || "未設定"}
                </p>
                {!!related.length && (
                  <div className="ml-4 mt-2 flex flex-wrap items-center gap-2">
                    <span className="text-xs font-black text-slate-500">関連資料</span>
                    {related.map((doc) => (
                      <button
                        key={doc.id}
                        type="button"
                        onClick={() => openDocument?.(doc.id)}
                        className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-3 py-1 text-sm font-bold text-blue-700 hover:bg-blue-100"
                      >
                        <FolderOpen size={14} />{doc.title}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <TaskDeadline t={t} patch={patch} />
              <Status t={t} patch={patch} />
              {patch && <EditTask t={t} patch={patch} />}
            </div>
          );
        })
      ) : (
        <p className="py-8 text-center text-slate-400">
          該当するタスクはありません
        </p>
      )}
    </div>
  );
}
function Focus({ tasks, patch }: { tasks: Task[]; patch: any }) {
  const gs = [
    [
      "今日やること",
      tasks.filter((t) => t.status !== "完了" && t.dueDate === today),
    ],
    [
      "今週やること",
      tasks.filter(
        (t) =>
          t.status !== "完了" && t.dueDate >= today && t.dueDate <= weekEnd,
      ),
    ],
    [
      "期限超過",
      tasks.filter(
        (t) => t.status !== "完了" && !!t.dueDate && t.dueDate < today,
      ),
    ],
    ["確認待ち", tasks.filter((t) => t.status === "確認待ち")],
  ] as [string, Task[]][];
  return (
    <div className="grid gap-5 xl:grid-cols-2">
      {gs.map((g) => (
        <Card key={g[0]} title={`${g[0]}　${g[1].length}件`}>
          <Rows rows={g[1]} patch={patch} />
        </Card>
      ))}
    </div>
  );
}
function Tasks({
  tasks,
  documents,
  openDocument,
  patch,
  create,
}: {
  tasks: Task[];
  documents: ProjectDocument[];
  openDocument: (id: number) => void;
  patch: any;
  create: any;
}) {
  const [f, setF] = useState("すべて"),
    [area, setArea] = useState("すべて"),
    [q, setQ] = useState("");
  const rows = tasks.filter(
    (t) =>
      (f === "すべて" || t.category === f) &&
      (area === "すべて" || t.scope === area) &&
      (!q.trim() || (`${t.id} ${t.name} ${t.memo} ${t.nextAction} ${t.contact}`).toLocaleLowerCase().includes(q.trim().toLocaleLowerCase())),
  );
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 text-slate-400" size={18} />
          <Input
            className="h-11 bg-white pl-10"
            aria-label="タスクを検索"
            placeholder="タスク名・メモ・IDで検索"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <select
          className="rounded-xl border bg-white px-3"
          value={area}
          onChange={(e) => setArea(e.target.value)}
        >
          {["すべて", "新棟オープン", "ケース対応"].map((x) => (
            <option key={x}>{x}</option>
          ))}
        </select>
        <select
          className="rounded-xl border bg-white px-3"
          value={f}
          onChange={(e) => setF(e.target.value)}
        >
          {["すべて", ...categories].map((x) => (
            <option key={x}>{x}</option>
          ))}
        </select>
        <Add
          type="tasks"
          label="タスク追加"
          fields={[
            ["name", "タスク名", "text"],
            ["scope", "仕事の種類", "select", ["新棟オープン", "ケース対応"]],
            ["category", "カテゴリ", "select", categories],
            ["dueDate", "期限", "date"],
            ["startMonth", "開始月", "month"],
            ["endMonth", "終了月", "month"],
            ["assignee", "担当者", "text"],
            ["priority", "優先度", "select", ["低", "中", "高", "最優先"]],
            ["nextAction", "次にやること", "text"],
            ["contact", "連絡先", "text"],
            ["memo", "メモ", "textarea"],
          ]}
          initial={{
            scope: "新棟オープン",
            category: categories[0],
            priority: "中",
            assignee: "藤田",
            status: "未着手",
            startMonth: today.slice(0, 7),
            endMonth: today.slice(0, 7),
          }}
          create={create}
        />
      </div>
      <Card title={`タスク一覧　${rows.length}件`}>
        <Rows
          rows={rows.sort((a, b) =>
            dueKey(a.dueDate).localeCompare(dueKey(b.dueDate)),
          )}
          patch={patch}
          documents={documents}
          openDocument={openDocument}
        />
      </Card>
    </div>
  );
}
const months = Array.from({ length: 12 }, (_, i) => {
  const d = new Date(2026, 8 + i, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
});
function Roadmap({ tasks }: { tasks: Task[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border bg-white">
      <div className="min-w-[1180px] p-5">
        <div className="grid grid-cols-[190px_repeat(12,1fr)] border-b pb-3 text-center text-xs font-bold text-slate-500">
          <span className="text-left">カテゴリ / タスク</span>
          {months.map((m) => (
            <span key={m}>{+m.slice(5)}月</span>
          ))}
        </div>
        {projectCategories.map((c) => (
          <div key={c} className="border-b py-4">
            <b className="mb-2 flex items-center gap-2">
              <i
                className="h-3 w-3 rounded-full"
                style={{ background: colors[c] }}
              />
              {c}
            </b>
            {tasks
              .filter((t) => t.category === c)
              .map((t) => {
                const a = Math.max(0, months.indexOf(t.startMonth)),
                  b = Math.max(a, months.indexOf(t.endMonth));
                return (
                  <div
                    key={t.id}
                    className="grid min-h-9 grid-cols-[190px_repeat(12,1fr)] items-center text-xs"
                  >
                    <span className="truncate pr-2">{t.name}</span>
                    <span className="relative col-span-12 grid h-7 grid-cols-12">
                      {months.map((m) => (
                        <i key={m} className="border-l border-slate-100" />
                      ))}
                      <b
                        className="absolute inset-y-1 rounded-full opacity-85"
                        style={{
                          left: `${(a / 12) * 100}%`,
                          width: `${((b - a + 1) / 12) * 100}%`,
                          background: colors[c],
                        }}
                      />
                    </span>
                  </div>
                );
              })}
          </div>
        ))}
      </div>
    </div>
  );
}
function Candidates({
  rows,
  patch,
  create,
}: {
  rows: Candidate[];
  patch: any;
  create: any;
}) {
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Add
          type="candidates"
          label="候補者追加"
          fields={[
            ["alias", "仮名または氏名", "text"],
            [
              "supportLevel",
              "障害支援区分",
              "select",
              ["区分3", "区分4", "区分5", "未確認"],
            ],
            ["daytimePlace", "日中活動先", "text"],
            ["supportOffice", "相談支援事業所", "text"],
            ["consultant", "担当相談員", "text"],
            ["interest", "入居希望度", "select", interests],
            ["familyIntent", "家族の意向", "text"],
            [
              "tourStatus",
              "見学状況",
              "select",
              ["未実施", "調整中", "見学済み"],
            ],
            [
              "trialStatus",
              "体験利用",
              "select",
              ["未実施", "調整中", "体験済み"],
            ],
            ["expectedMoveIn", "想定入居時期", "month"],
            ["nextContactDate", "次回連絡日", "date"],
            ["memo", "メモ", "textarea"],
          ]}
          initial={{
            supportLevel: "未確認",
            interest: "情報提供のみ",
            familyIntent: "未確認",
            tourStatus: "未実施",
            trialStatus: "未実施",
            expectedMoveIn: "2027-08",
          }}
          create={create}
        />
      </div>
      <Card
        title={`入居候補者　${rows.filter((r) => ["有力", "入居予定"].includes(r.interest)).length}/4名（有力＋入居予定）`}
      >
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>仮名・氏名</TableHead>
                <TableHead>区分</TableHead>
                <TableHead>日中活動先</TableHead>
                <TableHead>相談支援・担当</TableHead>
                <TableHead>希望度</TableHead>
                <TableHead>見学／体験</TableHead>
                <TableHead>次回連絡</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-bold">{r.alias}</TableCell>
                  <TableCell>{r.supportLevel}</TableCell>
                  <TableCell>{r.daytimePlace || "—"}</TableCell>
                  <TableCell>
                    {r.supportOffice || "—"}
                    <small className="block text-slate-500">
                      {r.consultant}
                    </small>
                  </TableCell>
                  <TableCell>
                    <select
                      className="rounded-full bg-orange-50 px-2 py-1 font-bold text-orange-700"
                      value={r.interest}
                      onChange={(e) =>
                        patch("candidates", r.id, { interest: e.target.value })
                      }
                    >
                      {interests.map((x) => (
                        <option key={x}>{x}</option>
                      ))}
                    </select>
                  </TableCell>
                  <TableCell>
                    {r.tourStatus}／{r.trialStatus}
                  </TableCell>
                  <TableCell>{fmt(r.nextContactDate)}</TableCell>
                </TableRow>
              ))}
              {!rows.length && (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    className="py-12 text-center text-slate-400"
                  >
                    候補者を追加すると、ここで進み具合を追えます
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
function Funds({
  funds,
  loans,
  patch,
  create,
}: {
  funds: Fund[];
  loans: Loan[];
  patch: any;
  create: any;
}) {
  const e = funds.reduce((a, b) => a + b.estimated, 0),
    c = funds.reduce((a, b) => a + b.confirmed, 0),
    p = funds.reduce((a, b) => a + b.paid, 0),
    b = loans.reduce((a, x) => a + x.requested, 0);
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[
          ["見込必要資金", e],
          ["確定額", c],
          ["支払済額", p],
          ["不足見込", Math.max(0, e - b)],
        ].map((x, i) => (
          <div key={x[0]} className="rounded-2xl border bg-white p-4">
            <p className="text-sm text-slate-500">{x[0]}</p>
            <b className={`text-2xl ${i === 3 ? "text-red-600" : ""}`}>
              {yen(x[1] as number)}
            </b>
          </div>
        ))}
      </div>
      <Card title="開設資金">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>項目</TableHead>
                <TableHead>見込額</TableHead>
                <TableHead>確定額</TableHead>
                <TableHead>支払済額</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {funds.map((f) => (
                <TableRow key={f.id}>
                  <TableCell className="font-bold">{f.item}</TableCell>
                  {(["estimated", "confirmed", "paid"] as const).map((k) => (
                    <TableCell key={k}>
                      <Input
                        type="number"
                        defaultValue={f[k]}
                        className="min-w-32"
                        onBlur={(x) =>
                          patch("funds", f.id, { [k]: +x.target.value })
                        }
                      />
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
      <Card title="借入先候補">
        <Add
          type="loans"
          label="借入候補を追加"
          fields={[
            ["lender", "借入先候補", "text"],
            ["requested", "借入希望額", "number"],
            ["consultationDate", "相談日", "date"],
            ["response", "金融機関からの回答", "text"],
            ["memo", "メモ", "textarea"],
          ]}
          initial={{ requested: 0, response: "未相談" }}
          create={create}
        />
        <div className="mt-4 divide-y">
          {loans.map((l) => (
            <div key={l.id} className="grid gap-2 py-3 sm:grid-cols-4">
              <b>{l.lender}</b>
              <span>{yen(l.requested)}</span>
              <span>{l.consultationDate || "相談日未定"}</span>
              <span>{l.response}</span>
            </div>
          ))}
          {!loans.length && (
            <p className="py-5 text-center text-slate-400">
              候補を登録すると不足額に反映されます
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}
function Contacts({
  rows,
  patch,
  create,
  remove,
}: {
  rows: Contact[];
  patch: any;
  create: any;
  remove: any;
}) {
  const sortedRows = [...rows].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Add
          type="contacts"
          label="連絡を記録"
          fields={[
            ["date", "日付", "date"],
            ["organization", "相手", "text"],
            ["person", "担当者", "text"],
            ["method", "方法", "select", contactMethods],
            ["content", "内容", "textarea"],
            ["response", "回答・追記コメント", "textarea"],
            ["nextDate", "次回対応日", "date"],
            ["waiting", "確認待ち", "checkbox"],
          ]}
          initial={{ date: today, method: "電話", waiting: false }}
          create={create}
        />
      </div>
      <Card title={`連絡履歴　${rows.length}件`}>
        <div className="space-y-3 md:hidden">
          {sortedRows.map((r) => (
            <article
              key={r.id}
              className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-blue-600">
                    {fmt(r.date)} ・ {r.method}
                  </p>
                  <h3 className="mt-1 text-lg font-black">{r.organization}</h3>
                  {r.person && (
                    <p className="text-sm text-slate-500">担当：{r.person}</p>
                  )}
                </div>
                {r.waiting && (
                  <span className="shrink-0 rounded-full bg-amber-100 px-3 py-1 text-sm font-bold text-amber-800">
                    確認待ち
                  </span>
                )}
              </div>
              <p className="mt-3 whitespace-pre-wrap">
                {r.content || "内容未入力"}
              </p>
              <div className="mt-3 rounded-xl bg-white p-3 text-sm">
                <b className="text-slate-500">回答・追記</b>
                <p className="mt-1 whitespace-pre-wrap">
                  {r.response || "まだありません"}
                </p>
              </div>
              <div className="mt-3 flex items-center justify-between text-sm">
                <span>
                  次回：<b>{fmt(r.nextDate)}</b>
                </span>
                <EditContact row={r} patch={patch} remove={remove} />
              </div>
            </article>
          ))}
          {!rows.length && (
            <p className="py-12 text-center text-slate-400">
              行政・大家・金融機関とのやり取りを残せます
            </p>
          )}
        </div>
        <div className="hidden overflow-x-auto md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>日付</TableHead>
                <TableHead>相手・担当</TableHead>
                <TableHead>方法</TableHead>
                <TableHead>内容・回答</TableHead>
                <TableHead>次回</TableHead>
                <TableHead>確認待ち</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedRows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>{fmt(r.date)}</TableCell>
                  <TableCell className="font-bold">
                    {r.organization}
                    <small className="block text-slate-500">{r.person}</small>
                  </TableCell>
                  <TableCell>{r.method}</TableCell>
                  <TableCell className="max-w-md whitespace-pre-wrap">
                    {r.content}
                    <small className="block text-slate-500">
                      回答・追記：{r.response || "—"}
                    </small>
                  </TableCell>
                  <TableCell>{fmt(r.nextDate)}</TableCell>
                  <TableCell>
                    <input
                      aria-label="確認待ち"
                      type="checkbox"
                      checked={r.waiting}
                      onChange={(e) =>
                        patch("contacts", r.id, { waiting: e.target.checked })
                      }
                      className="h-5 w-5"
                    />
                  </TableCell>
                  <TableCell>
                    <EditContact row={r} patch={patch} remove={remove} />
                  </TableCell>
                </TableRow>
              ))}
              {!rows.length && (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    className="py-12 text-center text-slate-400"
                  >
                    行政・大家・金融機関とのやり取りを残せます
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}

function EditContact({
  row,
  patch,
  remove,
}: {
  row: Contact;
  patch: any;
  remove: any;
}) {
  const [open, setOpen] = useState(false),
    [v, setV] = useState({ ...row }),
    [saving, setSaving] = useState(false);
  useEffect(() => {
    if (open) setV({ ...row });
  }, [open, row]);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
    if (
      await patch("contacts", row.id, {
        date: v.date,
        organization: v.organization,
        person: v.person,
        method: v.method,
        content: v.content,
        response: v.response,
        nextDate: v.nextDate,
        waiting: v.waiting,
      })
    )
      setOpen(false);
    } finally { setSaving(false); }
  };
  const del = async () => {
    if (saving) return;
    setSaving(true);
    try { if (await remove("contacts", row.id)) setOpen(false); }
    finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(next) => !saving && setOpen(next)}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-11 px-4 font-bold">
          編集・追記
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[92dvh] overflow-hidden p-0 sm:max-w-lg">
        <DialogHeader className="px-5 pt-5">
          <DialogTitle>連絡履歴を編集</DialogTitle>
        </DialogHeader>
        <form
          onSubmit={submit}
          className="max-h-[calc(92dvh-4rem)] space-y-4 overflow-y-auto px-5 pb-2"
        >
          <label className="block text-sm font-bold">
            日付
            <Input
              className="mt-1"
              type="date"
              value={v.date || ""}
              onChange={(e) => setV({ ...v, date: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            相手
            <Input
              className="mt-1"
              value={v.organization || ""}
              onChange={(e) => setV({ ...v, organization: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            担当者
            <Input
              className="mt-1"
              value={v.person || ""}
              onChange={(e) => setV({ ...v, person: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            方法
            <select
              className="mt-1 h-11 w-full rounded-lg border bg-white px-3"
              value={v.method}
              onChange={(e) => setV({ ...v, method: e.target.value })}
            >
              {contactMethods.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-bold">
            内容
            <Textarea
              className="mt-1 min-h-24"
              value={v.content || ""}
              onChange={(e) => setV({ ...v, content: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            回答・追記コメント
            <Textarea
              className="mt-1 min-h-28"
              placeholder="後から分かったことや回答を追記できます"
              value={v.response || ""}
              onChange={(e) => setV({ ...v, response: e.target.value })}
            />
          </label>
          <label className="block text-sm font-bold">
            次回対応日
            <Input
              className="mt-1"
              type="date"
              value={v.nextDate || ""}
              onChange={(e) => setV({ ...v, nextDate: e.target.value })}
            />
          </label>
          <label className="flex min-h-11 items-center gap-3 text-sm font-bold">
            <input
              className="h-6 w-6"
              type="checkbox"
              checked={!!v.waiting}
              onChange={(e) => setV({ ...v, waiting: e.target.checked })}
            />
            確認待ち
          </label>
          <div className="sticky bottom-0 -mx-5 flex gap-2 border-t bg-white px-5 pb-[max(.75rem,env(safe-area-inset-bottom))] pt-3">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  type="button"
                  disabled={saving}
                  variant="outline"
                  className="h-12 border-red-200 px-4 text-red-600"
                >
                  削除
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>
                    この連絡履歴を削除しますか？
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    削除すると元に戻せません。重複して登録した履歴の整理に使えます。
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>キャンセル</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={del}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    削除する
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button
              type="submit"
              disabled={saving}
              className="h-12 flex-1 bg-blue-600 text-base font-black shadow-lg"
            >
              {saving ? "保存中…" : "変更を保存"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
type Field = [string, string, string, string[]?];
function Add({
  type,
  label,
  fields,
  initial,
  create,
}: {
  type: string;
  label: string;
  fields: Field[];
  initial: Record<string, any>;
  create: any;
}) {
  const [open, setOpen] = useState(false),
    [v, setV] = useState(initial),
    [saving, setSaving] = useState(false);
  const openForm = (next: boolean) => {
    if (saving) return;
    if (next) setV({ ...initial, ...Object.fromEntries(fields.map(([key, , kind, options]) =>
      [key, initial[key] ?? (kind === "select" ? options?.[0] : kind === "checkbox" ? false : "")])) });
    setOpen(next);
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      const out = { ...v };
      if (type === "loans") out.requested = +out.requested;
      if (await create(type, out)) setOpen(false);
    } finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={openForm}>
      <DialogTrigger asChild>
        <Button className="bg-blue-600">
          <Plus />
          {label}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{label}</DialogTitle>
        </DialogHeader>
        <form
          onSubmit={submit}
          className="max-h-[70vh] space-y-4 overflow-y-auto px-1"
        >
          {fields.map(([k, l, t, o]) => (
            <label key={k} className="block text-sm font-bold">
              {l}
              {t === "textarea" ? (
                <Textarea
                  required={type === "contacts" && k === "content"}
                  className="mt-1"
                  value={v[k] || ""}
                  onChange={(e) => setV({ ...v, [k]: e.target.value })}
                />
              ) : t === "select" ? (
                <select
                  className="mt-1 h-10 w-full rounded-lg border bg-white px-3"
                  value={v[k] || o?.[0]}
                  onChange={(e) => setV({ ...v, [k]: e.target.value })}
                >
                  {o?.map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              ) : t === "checkbox" ? (
                <input
                  className="ml-3 h-5 w-5"
                  type="checkbox"
                  checked={!!v[k]}
                  onChange={(e) => setV({ ...v, [k]: e.target.checked })}
                />
              ) : (
                <Input
                  required={(type === "tasks" && ["name", "dueDate"].includes(k)) || (type === "contacts" && ["date", "organization"].includes(k))}
                  className="mt-1"
                  type={t}
                  value={v[k] ?? ""}
                  onChange={(e) => setV({ ...v, [k]: e.target.value })}
                />
              )}
            </label>
          ))}
          <div className="sticky bottom-0 -mx-1 bg-white px-1 pb-[max(.5rem,env(safe-area-inset-bottom))] pt-3">
            <Button
              type="submit"
              disabled={saving}
              className="h-12 w-full bg-blue-600 text-base font-black shadow-lg"
            >
              {saving ? "保存中…" : "保存する"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

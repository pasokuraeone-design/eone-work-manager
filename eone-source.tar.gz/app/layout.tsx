import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "イーワンスクエア 仕事管理",
  description: "新棟オープン準備と利用者対応を一つの入口で管理するアプリ",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}

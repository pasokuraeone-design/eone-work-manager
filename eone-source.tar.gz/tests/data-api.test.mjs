import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync, readdirSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { build } from "esbuild";

// Run the actual route/Drizzle code against a disposable SQLite D1 adapter.
// An optional read-only production snapshot stays outside the repository.
const sqlite = new DatabaseSync(":memory:");
for (const file of readdirSync("drizzle").filter((file) => file.endsWith(".sql")).sort())
  sqlite.exec(readFileSync(`drizzle/${file}`, "utf8"));
class Statement {
  constructor(query, values = []) { this.query = query; this.values = values; }
  bind(...values) { return new Statement(this.query, values); }
  async all() { return { success: true, results: sqlite.prepare(this.query).all(...this.values) }; }
  async raw() { return (await this.all()).results.map(Object.values); }
  async run() { return { success: true, meta: sqlite.prepare(this.query).run(...this.values) }; }
}
globalThis.__testWorkerEnv = { DB: {
  prepare(query) { return new Statement(query); },
  async batch(statements) {
    sqlite.exec("BEGIN");
    try {
      const results = [];
      for (const statement of statements) results.push(await statement.all());
      sqlite.exec("COMMIT");
      return results;
    } catch (error) { sqlite.exec("ROLLBACK"); throw error; }
  },
} };
if (process.env.EONE_TEST_SNAPSHOT) {
  const snapshot = JSON.parse(readFileSync(process.env.EONE_TEST_SNAPSHOT, "utf8"));
  for (const [table, value] of Object.entries(snapshot)) {
    assert.equal(value.model_projection.truncated, false);
    assert.equal(value.model_projection.truncated_values, 0);
    assert.equal(value.model_projection.next_offset, null);
    for (const row of value.rows) {
      const keys = Object.keys(row);
      sqlite.prepare(`INSERT INTO "${table}" (${keys.map((key) => `"${key}"`).join(",")}) VALUES (${keys.map(() => "?").join(",")})`).run(...Object.values(row));
    }
  }
} else {
  sqlite.exec(`INSERT INTO tasks (id,name,category,due_date,memo,next_action,start_month,end_month) VALUES (41,'大家の融資正式結果を確認し、新築プランを検討','建物・消防・備品','2026-10-19','10月19日14時、グリーンホーム・アドバンス（株）。参加返信済み・場所確定。大家側融資はほぼ通りそうだが正式承認未確認。','正式結果を確認','2026-10','2026-10');
    INSERT INTO contacts (date,organization,method,content) VALUES ('2026-10-16','大家','LINE','打ち合わせの連絡');
    INSERT INTO project_update_log (key) VALUES ('yamate-plan-2026-10-23');`);
}
const { outputFiles } = await build({
  entryPoints: ["app/api/data/route.ts"], bundle: true, write: false, platform: "node", format: "esm",
  plugins: [{ name: "test-worker-env", setup(builder) {
    builder.onResolve({ filter: /^cloudflare:workers$/ }, () => ({ path: "env", namespace: "test" }));
    builder.onLoad({ filter: /.*/, namespace: "test" }, () => ({ contents: "export const env = globalThis.__testWorkerEnv;" }));
  } }],
});
const route = await import(`data:text/javascript;base64,${Buffer.from(outputFiles[0].text).toString("base64")}`);
const request = (method, body) => route[method](new Request("https://app.test/api/data", {
  method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
}));
const dump = () => Object.fromEntries(sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map(({ name }) => [name, sqlite.prepare(`SELECT * FROM "${name}" ORDER BY rowid`).all()]));

test("task edits and LINE contacts persist; repeated loads preserve all existing records", async () => {
  const originalSnapshot = dump();
  const first = await (await route.GET()).json();
  if (process.env.EONE_TEST_SNAPSHOT) assert.deepEqual(dump(), originalSnapshot);
  const before = dump();
  assert.equal(first.tasks.filter((task) => task.id === 41).length, 1);
  assert.equal(first.contacts.filter((contact) => contact.date === "2026-10-16" && contact.method === "LINE").length, 1);
  const original = first.tasks.find((task) => task.id === 41);
  assert.equal(original.startMonth, "2026-10");
  assert.equal(original.endMonth, "2026-10");
  assert.match(original.memo, /14時/);
  assert.match(original.memo, /グリーンホーム・アドバンス/);
  assert.match(original.memo, /正式承認.*未確認/);
  const changed = { name: original.name + "（確認テスト）", memo: original.memo + "\n保存テスト", nextAction: "次のアクション\n改行も保存", startMonth: "2026-10", endMonth: "2026-11" };
  const saved = await request("PATCH", { table: "tasks", id: 41, data: changed });
  assert.equal(saved.status, 200);
  const reloaded = (await (await route.GET()).json()).tasks.find((task) => task.id === 41);
  assert.deepEqual(reloaded, { ...original, ...changed });
  assert.equal((await request("PATCH", { table: "tasks", id: 41, data: Object.fromEntries(Object.keys(changed).map((key) => [key, original[key]])) })).status, 200);
  const created = await request("POST", { table: "contacts", data: { date: "2026-10-23", organization: "動作確認用", method: "LINE", content: "テスト用連絡", waiting: false } });
  assert.equal(created.status, 201);
  const { row } = await created.json();
  assert.equal((await request("PATCH", { table: "contacts", id: row.id, data: { response: "追記を保存" } })).status, 200);
  const contact = (await (await route.GET()).json()).contacts.find((contact) => contact.id === row.id);
  assert.equal(contact.method, "LINE");
  assert.equal(contact.response, "追記を保存");
  assert.equal((await request("DELETE", { table: "contacts", id: row.id })).status, 200);
  await route.GET();
  assert.deepEqual(dump(), before);
});

test("bad table, ID, empty task, reversed months, and missing record cannot silently change data", async () => {
  const before = dump();
  for (const method of ["PATCH", "DELETE", "POST"])
    assert.equal((await request(method, { table: "unknown", id: 7, data: { content: "invalid" } })).status, 400);
  for (const body of [
    { table: "tasks", id: 0, data: { memo: "invalid" } },
    { table: "tasks", id: 41, data: { name: "  " } },
    { table: "tasks", id: 41, data: { id: 42 } },
    { table: "tasks", id: 41, data: { startMonth: "2026-11", endMonth: "2026-10" } },
    { table: "tasks", id: 41, data: { memo: null } },
  ]) assert.equal((await request("PATCH", body)).status, 400);
  assert.equal((await request("PATCH", { table: "tasks", id: 999999, data: { memo: "missing" } })).status, 404);
  assert.deepEqual(dump(), before);
});

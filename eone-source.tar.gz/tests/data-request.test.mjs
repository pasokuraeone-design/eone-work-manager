import assert from "node:assert/strict";
import { test } from "node:test";
import { dataRequest } from "../lib/data-request.ts";

test("save errors are explicit and are never automatically retried", async (t) => {
  const originalFetch = globalThis.fetch;
  t.after(() => { globalThis.fetch = originalFetch; });
  let calls = 0;
  globalThis.fetch = async () => { calls++; throw new TypeError("offline"); };
  await assert.rejects(dataRequest("PATCH", {}), /入力内容は残っています/);
  assert.equal(calls, 1);
  globalThis.fetch = async () => Response.json({ error: "タスク名を入力してください。" }, { status: 400 });
  await assert.rejects(dataRequest("PATCH", {}), /タスク名/);
  globalThis.fetch = async () => new Response("<html>sign in</html>");
  await assert.rejects(dataRequest("POST", {}), /保存結果を確認できません/);
  globalThis.fetch = async () => Response.json({});
  await assert.rejects(dataRequest("PATCH", {}), /保存対象が見つかりません/);
  globalThis.fetch = async () => Response.json({ row: { id: 41 } });
  assert.equal((await dataRequest("PATCH", {})).row.id, 41);
});

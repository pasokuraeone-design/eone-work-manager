CREATE UNIQUE INDEX `idx_funds_item_unique` ON `funds` (`item`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_tasks_name_unique` ON `tasks` (`name`);--> statement-breakpoint
PRAGMA optimize;

CREATE TABLE `case_memos` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`person_name` text NOT NULL,
	`date` text NOT NULL,
	`title` text NOT NULL,
	`content` text NOT NULL,
	`next_action` text DEFAULT '' NOT NULL,
	`due_date` text DEFAULT '' NOT NULL,
	`priority` text DEFAULT '中' NOT NULL,
	`task_id` integer
);
--> statement-breakpoint
CREATE INDEX `idx_case_memos_person_date` ON `case_memos` (`person_name`,`date`);--> statement-breakpoint
CREATE INDEX `idx_case_memos_task_id` ON `case_memos` (`task_id`);
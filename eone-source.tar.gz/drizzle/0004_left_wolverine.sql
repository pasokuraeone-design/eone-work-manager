ALTER TABLE `tasks` ADD `scope` text DEFAULT '新棟オープン' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_tasks_scope_due` ON `tasks` (`scope`,`due_date`);
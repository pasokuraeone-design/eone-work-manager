CREATE TABLE `case_updates` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`case_id` integer NOT NULL,
	`date` text NOT NULL,
	`stage` text NOT NULL,
	`content` text NOT NULL,
	`next_action` text DEFAULT '' NOT NULL,
	`due_date` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_case_updates_case_date` ON `case_updates` (`case_id`,`date`);--> statement-breakpoint
CREATE INDEX `idx_case_updates_stage` ON `case_updates` (`stage`);--> statement-breakpoint
ALTER TABLE `case_memos` ADD `stage` text DEFAULT '受付・対応中' NOT NULL;
CREATE TABLE `borrowings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lender` text NOT NULL,
	`original_amount` integer DEFAULT 0 NOT NULL,
	`current_balance` integer DEFAULT 0 NOT NULL,
	`monthly_principal` integer DEFAULT 0 NOT NULL,
	`monthly_payment` integer DEFAULT 0 NOT NULL,
	`interest_rate` real DEFAULT 0 NOT NULL,
	`maturity_date` text DEFAULT '' NOT NULL,
	`schedule_url` text DEFAULT '' NOT NULL,
	`memo` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_borrowings_maturity_date` ON `borrowings` (`maturity_date`);--> statement-breakpoint
CREATE TABLE `project_documents` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`category` text NOT NULL,
	`summary` text DEFAULT '' NOT NULL,
	`key_numbers` text DEFAULT '' NOT NULL,
	`updated_date` text DEFAULT '' NOT NULL,
	`drive_url` text NOT NULL,
	`related_task_ids` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_project_documents_category` ON `project_documents` (`category`);--> statement-breakpoint
CREATE INDEX `idx_project_documents_updated_date` ON `project_documents` (`updated_date`);
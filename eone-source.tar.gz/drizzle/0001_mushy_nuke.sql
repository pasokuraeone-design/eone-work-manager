CREATE INDEX `idx_candidates_interest` ON `candidates` (`interest`);--> statement-breakpoint
CREATE INDEX `idx_contacts_waiting_next` ON `contacts` (`waiting`,`next_date`);--> statement-breakpoint
CREATE INDEX `idx_tasks_due_status` ON `tasks` (`due_date`,`status`);--> statement-breakpoint
CREATE INDEX `idx_tasks_category` ON `tasks` (`category`);--> statement-breakpoint
PRAGMA optimize;

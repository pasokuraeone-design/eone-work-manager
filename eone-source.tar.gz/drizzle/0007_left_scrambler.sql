CREATE TABLE `project_update_log` (
	`key` text PRIMARY KEY NOT NULL
);

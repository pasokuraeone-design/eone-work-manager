CREATE TABLE `candidates` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`alias` text NOT NULL,
	`support_level` text DEFAULT '未確認' NOT NULL,
	`daytime_place` text DEFAULT '' NOT NULL,
	`support_office` text DEFAULT '' NOT NULL,
	`consultant` text DEFAULT '' NOT NULL,
	`interest` text DEFAULT '情報提供のみ' NOT NULL,
	`family_intent` text DEFAULT '未確認' NOT NULL,
	`tour_status` text DEFAULT '未実施' NOT NULL,
	`trial_status` text DEFAULT '未実施' NOT NULL,
	`expected_move_in` text DEFAULT '2027-08' NOT NULL,
	`next_contact_date` text DEFAULT '' NOT NULL,
	`memo` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`date` text NOT NULL,
	`organization` text NOT NULL,
	`person` text DEFAULT '' NOT NULL,
	`method` text DEFAULT '電話' NOT NULL,
	`content` text NOT NULL,
	`response` text DEFAULT '' NOT NULL,
	`next_date` text DEFAULT '' NOT NULL,
	`waiting` integer DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE `funds` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`item` text NOT NULL,
	`estimated` integer DEFAULT 0 NOT NULL,
	`confirmed` integer DEFAULT 0 NOT NULL,
	`paid` integer DEFAULT 0 NOT NULL,
	`memo` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `loans` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lender` text NOT NULL,
	`requested` integer DEFAULT 0 NOT NULL,
	`consultation_date` text DEFAULT '' NOT NULL,
	`response` text DEFAULT '未相談' NOT NULL,
	`memo` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`category` text NOT NULL,
	`due_date` text NOT NULL,
	`assignee` text DEFAULT '藤田' NOT NULL,
	`priority` text DEFAULT '中' NOT NULL,
	`status` text DEFAULT '未着手' NOT NULL,
	`memo` text DEFAULT '' NOT NULL,
	`next_action` text DEFAULT '' NOT NULL,
	`contact` text DEFAULT '' NOT NULL,
	`resource_url` text DEFAULT '' NOT NULL,
	`start_month` text DEFAULT '2026-09' NOT NULL,
	`end_month` text DEFAULT '2026-09' NOT NULL
);
